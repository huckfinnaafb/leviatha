<?php include(F3::get('GUI') . "/includes/header.php") ?>
<div class="line">
    <div class="unit size2of3">
        <!-- Common Properties -->
        <div class="module">
            <h1 class="h-page h-mod"><?php echo $this->db_item["common"]["name"] ?></h1>
            <img src="/img/stormshield.png" style="float: left; margin: 0 10px 10px 0;">
            <p class="text-info">Level <?php echo $this->db_item["common"]["level"] . " <a href='/loot?item=" . $this->db_item["common"]["classurl"] . "'>" . ucwords($this->db_item["common"]["class"]) ?></a></p>
            <p class="text-info">Required Level: <?php echo $this->db_item["common"]["levelreq"]; ?></p>
        </div>
        
        <!-- Similar Items -->
        <?php include(F3::get('GUI') . "loot/modules/similar.php") ?>
    </div>

    <div class="unit size2of3 lastUnit">
        <!-- Normal Properties -->
        <?php include(F3::get('GUI') . "loot/modules/props_normal.php") ?>
        
        <!-- Magic Properties -->
        <?php include(F3::get('GUI') . "loot/modules/props_magic.php") ?>
    </div>
</div>

<!-- Footer -->
<?php include(F3::get('GUI') . "/includes/footer.php") ?>
