<div class="module">
    <h1 class="h-mod">Family Set Bonuses</h1>
    <table>
        <tbody>
            <?php
                try {
                    if (isset($this->db_family["props"]) && (!empty($this->db_family["props"]))) {
                        foreach($this->db_family["props"] as $row) {
                            echo "<tr class='set'>";
                                echo "<td>{$row['property']}</td>";
                                if (isset($row["parameter"])) 
                                    echo "<td>{$row['parameter']}</td>";
                                else
                                    echo "<td></td>";
                                
                                if (isset($row["min"]) && isset($row["max"])) {
                                    if ($row["min"] == $row["max"]) {
                                        echo "<td>{$row["min"]}</td>";
                                    } else {
                                        echo "<td>{$row["min"]} - {$row["max"]}</td>";
                                    }
                                } else {
                                    echo "<td></td>";
                                }
                                
                                if (count($this->db_family["members"]) == $row["req_equip"]) {
                                    echo "<td>( Full Set Bonus )</td>";
                                } else {
                                    echo "<td>( " . ($row["req_equip"]) . " Equipped )</td>";
                                }
                                
                            echo "</tr>";
                        }
                    } else {
                        throw new Exception("No set bonuses found.");
                    }
                } catch (Exception $e) {
                    echo "<p>" . $e->getMessage(), "</p>\n";
                }
            ?>
        </tbody>
    </table>
</div>
