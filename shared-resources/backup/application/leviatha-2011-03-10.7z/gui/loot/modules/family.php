<div class="module">
    <h1 class="h-mod"><?php echo $this->db_family["family"] ?></h1>
    <ul class="list-directory">
        <?php
            foreach($this->db_family["members"] as $row) {
                echo "<li><a href='/loot?item={$row["urlname"]}'>{$row["name"]}</a></li>";
            }
        ?>
    </ul>
</div>
