<?php include(F3::get('GUI') . "/includes/header.php") ?>
<div class="module mod-tip"> 
<p>Expand each section to see common items and their magical equivalents, ordered by group alphabetically and then in ascending order by level.</p> 
</div> 
<div class="module"> 
<h1 class="h-mod h-page">Master Loot Directory</h1> 
<ul class="list-directory"> 
<li>Accessory</li> 
<ul><li>Charm</li> 
<ul><li><a href='/loot?item=charm'>Charm</a></li> 
<ul><li><a href='/loot?item=annihilus'>Annihilus</a></li> 
<li><a href='/loot?item=hellfire-torch'>Hellfire Torch</a></li> 
<li><a href='/loot?item=gheeds-fortune'>Gheed's Fortune</a></li> 
</ul> 
</ul> 
<li>Jewelry</li> 
<ul><li><a href='/loot?item=amulet'>Amulet</a></li> 
<ul><li><a href='/loot?item=metalgrid'>Metalgrid</a></li> 
<li><a href='/loot?item=maras-kaleidoscope'>Mara's Kaleidoscope</a></li> 
<li><a href='/loot?item=seraphs-hymn'>Seraph's Hymn</a></li> 
<li><a href='/loot?item=the-rising-sun'>The Rising Sun</a></li> 
<li><a href='/loot?item=highlords-wrath'>Highlord's Wrath</a></li> 
<li><a href='/loot?item=atmas-scarab'>Atma's Scarab</a></li> 
<li><a href='/loot?item=crescent-moon'>Crescent Moon</a></li> 
<li><a href='/loot?item=the-cats-eye'>The Cat's Eye</a></li> 
<li><a href='/loot?item=saracens-chance'>Saracen's Chance</a></li> 
<li><a href='/loot?item=the-mahim-oak-curio'>The Mahim-Oak Curio</a></li> 
<li><a href='/loot?item=the-eye-of-etlich'>The Eye Of Etlich</a></li> 
<li><a href='/loot?item=nokozan-relic'>Nokozan Relic</a></li> 
<li><a href='/loot?item=amulet-of-the-viper'>Amulet Of The Viper</a></li> 
</ul> 
<li><a href='/loot?item=ring'>Ring</a></li> 
<ul><li><a href='/loot?item=constricting-ring'>Constricting Ring</a></li> 
<li><a href='/loot?item=wisp'>Wisp</a></li> 
<li><a href='/loot?item=natures-peace'>Nature's Peace</a></li> 
<li><a href='/loot?item=carrion-wind'>Carrion Wind</a></li> 
<li><a href='/loot?item=bul-kathos-wedding-band'>Bul Katho's Wedding Band</a></li> 
<li><a href='/loot?item=dwarf-star'>Dwarf Star</a></li> 
<li><a href='/loot?item=raven-frost'>Raven Frost</a></li> 
<li><a href='/loot?item=the-stone-of-jordan'>The Stone Of Jordan</a></li> 
<li><a href='/loot?item=manald-heal'>Manald Heal</a></li> 
<li><a href='/loot?item=nagelring'>Nagelring</a></li> 
</ul> 
</ul> 
</ul> 
<li>Armor</li> 
<ul><li>Barbarian Headgear</li> 
<ul><li><a href='/loot?item=guardian-crown'>Guardian Crown</a></li> 
<li><a href='/loot?item=conqueror-crown'>Conqueror Crown</a></li> 
<ul><li><a href='/loot?item=halaberds-reign'>Halaberd's Reign</a></li> 
</ul> 
<li><a href='/loot?item=destroyer-helm'>Destroyer Helm</a></li> 
<ul><li><a href='/loot?item=demonhorns-edge'>Demonhorn's Edge</a></li> 
</ul> 
<li><a href='/loot?item=fury-visor'>Fury Visor</a></li> 
<ul><li><a href='/loot?item=wolfhowl'>Wolfhowl</a></li> 
</ul> 
<li><a href='/loot?item=carnage-helm'>Carnage Helm</a></li> 
<li><a href='/loot?item=slayer-guard'>Slayer Guard</a></li> 
<ul><li><a href='/loot?item=arreats-face'>Arreat's Face</a></li> 
</ul> 
<li><a href='/loot?item=savage-helmet'>Savage Helmet</a></li> 
<li><a href='/loot?item=rage-mask'>Rage Mask</a></li> 
<li><a href='/loot?item=lion-helm'>Lion Helm</a></li> 
<li><a href='/loot?item=jawbone-visor'>Jawbone Visor</a></li> 
<li><a href='/loot?item=avenger-guard'>Avenger Guard</a></li> 
<li><a href='/loot?item=assault-helmet'>Assault Helmet</a></li> 
<li><a href='/loot?item=horned-helm'>Horned Helm</a></li> 
<li><a href='/loot?item=fanged-helm'>Fanged Helm</a></li> 
<li><a href='/loot?item=jawbone-cap'>Jawbone Cap</a></li> 
</ul> 
<li>Belt</li> 
<ul><li><a href='/loot?item=colossus-girdle'>Colossus Girdle</a></li> 
<li><a href='/loot?item=troll-belt'>Troll Belt</a></li> 
<li><a href='/loot?item=mithril-coil'>Mithril Coil</a></li> 
<ul><li><a href='/loot?item=verdugos-hearty-cord'>Verdugo's Hearty Cord</a></li> 
</ul> 
<li><a href='/loot?item=vampirefang-belt'>Vampirefang Belt</a></li> 
<ul><li><a href='/loot?item=nosferatus-coil'>Nosferatu's Coil</a></li> 
</ul> 
<li><a href='/loot?item=spiderweb-sash'>Spiderweb Sash</a></li> 
<ul><li><a href='/loot?item=arachnid-mesh'>Arachnid Mesh</a></li> 
</ul> 
<li><a href='/loot?item=war-belt'>War Belt</a></li> 
<ul><li><a href='/loot?item=thudergods-vigor'>Thudergod's Vigor</a></li> 
</ul> 
<li><a href='/loot?item=battle-belt'>Battle Belt</a></li> 
<ul><li><a href='/loot?item=snowclash'>Snowclash</a></li> 
</ul> 
<li><a href='/loot?item=mesh-belt'>Mesh Belt</a></li> 
<ul><li><a href='/loot?item=gloomstrap'>Gloomstrap</a></li> 
</ul> 
<li><a href='/loot?item=sharkskin-belt'>Sharkskin Belt</a></li> 
<ul><li><a href='/loot?item=razortail'>Razortail</a></li> 
</ul> 
<li><a href='/loot?item=demonhide-sash'>Demonhide Sash</a></li> 
<ul><li><a href='/loot?item=string-of-ears'>String Of Ears</a></li> 
</ul> 
<li><a href='/loot?item=girdle'>Girdle</a></li> 
<ul><li><a href='/loot?item=bladebuckle'>Bladebuckle</a></li> 
</ul> 
<li><a href='/loot?item=heavy-belt'>Heavy Belt</a></li> 
<ul><li><a href='/loot?item=goldwrap'>Goldwrap</a></li> 
</ul> 
<li><a href='/loot?item=Belt'>Belt</a></li> 
<ul><li><a href='/loot?item=nightsmoke'>Nightsmoke</a></li> 
</ul> 
<li><a href='/loot?item=light-belt'>Light Belt</a></li> 
<ul><li><a href='/loot?item=snakecord'>Snakecord</a></li> 
</ul> 
<li><a href='/loot?item=sash'>Sash</a></li> 
<ul><li><a href='/loot?item=lenyms-cord'>Lenyms Cord</a></li> 
</ul> 
</ul> 
<li>Boots</li> 
<ul><li><a href='/loot?item=myrmidon-greaves'>Myrmidon Greaves</a></li> 
<ul><li><a href='/loot?item=shadowdancer'>Shadowdancer</a></li> 
</ul> 
<li><a href='/loot?item=mirrored-boots'>Mirrored Boots</a></li> 
<li><a href='/loot?item=boneweave-boots'>Boneweave Boots</a></li> 
<ul><li><a href='/loot?item=marrowwalk'>Marrowwalk</a></li> 
</ul> 
<li><a href='/loot?item=scarabshell-boots'>Scarabshell Boots</a></li> 
<ul><li><a href='/loot?item=sandstorm-trek'>Sandstorm Trek</a></li> 
</ul> 
<li><a href='/loot?item=wyrmhide-boots'>Wyrmhide Boots</a></li> 
<li><a href='/loot?item=war-boots'>War Boots</a></li> 
<ul><li><a href='/loot?item=gorerider'>Gorerider</a></li> 
</ul> 
<li><a href='/loot?item=battle-boots'>Battle Boots</a></li> 
<ul><li><a href='/loot?item=wartraveler'>Wartraveler</a></li> 
</ul> 
<li><a href='/loot?item=mesh-boots'>Mesh Boots</a></li> 
<ul><li><a href='/loot?item=silkweave'>Silkweave</a></li> 
</ul> 
<li><a href='/loot?item=sharkskin-boots'>Sharkskin Boots</a></li> 
<ul><li><a href='/loot?item=waterwalk'>Waterwalk</a></li> 
</ul> 
<li><a href='/loot?item=demonhide-boots'>Demonhide Boots</a></li> 
<ul><li><a href='/loot?item=infernostride'>Infernostride</a></li> 
</ul> 
<li><a href='/loot?item=plate-boots'>Plate Boots</a></li> 
<ul><li><a href='/loot?item=tearhaunch'>Tearhaunch</a></li> 
</ul> 
<li><a href='/loot?item=light-plate-boots'>Light Plate Boots</a></li> 
<ul><li><a href='/loot?item=goblin-toe'>Goblin Toe</a></li> 
</ul> 
<li><a href='/loot?item=chain-boots'>Chain Boots</a></li> 
<ul><li><a href='/loot?item=treads-of-cthon'>Treads Of Cthon</a></li> 
</ul> 
<li><a href='/loot?item=heavy-boots'>Heavy Boots</a></li> 
<ul><li><a href='/loot?item=gorefoot'>Gorefoot</a></li> 
</ul> 
<li><a href='/loot?item=leather-boots'>Leather Boots</a></li> 
<ul><li><a href='/loot?item=hotspur'>Hotspur</a></li> 
</ul> 
</ul> 
<li>Chest Armor</li> 
<ul><li><a href='/loot?item=sacred-armor'>Sacred Armor</a></li> 
<ul><li><a href='/loot?item=tyraels-might'>Tyrael's Might</a></li> 
<li><a href='/loot?item=templars-might'>Templar's Might</a></li> 
</ul> 
<li><a href='/loot?item=archon-plate'>Archon Plate</a></li> 
<li><a href='/loot?item=shadow-plate'>Shadow Plate</a></li> 
<ul><li><a href='/loot?item=steel-carapice'>Steel Carapice</a></li> 
</ul> 
<li><a href='/loot?item=lacquered-plate'>Lacquered Plate</a></li> 
<li><a href='/loot?item=kraken-shell'>Kraken Shell</a></li> 
<ul><li><a href='/loot?item=leviathan'>Leviathan</a></li> 
</ul> 
<li><a href='/loot?item=hellforged-plate'>Hellforged Plate</a></li> 
<li><a href='/loot?item=balrog-skin'>Balrog Skin</a></li> 
<ul><li><a href='/loot?item=arkaines-valor'>Arkaine's Valor</a></li> 
</ul> 
<li><a href='/loot?item=great-hauberk'>Great Hauberk</a></li> 
<li><a href='/loot?item=loricated-mail'>Loricated Mail</a></li> 
<li><a href='/loot?item=diamond-mail'>Diamond Mail</a></li> 
<li><a href='/loot?item=wire-fleece'>Wire Fleece</a></li> 
<ul><li><a href='/loot?item=the-gladiators-bane'>The Gladiator's Bane</a></li> 
</ul> 
<li><a href='/loot?item=scarab-husk'>Scarab Husk</a></li> 
<li><a href='/loot?item=wyrmhide'>Wyrmhide</a></li> 
<li><a href='/loot?item=dusk-shroud'>Dusk Shroud</a></li> 
<ul><li><a href='/loot?item=ormus-robes'>Ormus' Robes</a></li> 
</ul> 
<li><a href='/loot?item=ornate-armor'>Ornate Armor</a></li> 
<ul><li><a href='/loot?item=corpsemourn'>Corpsemourn</a></li> 
</ul> 
<li><a href='/loot?item=boneweave'>Boneweave</a></li> 
<li><a href='/loot?item=chaos-armor'>Chaos Armor</a></li> 
<ul><li><a href='/loot?item=black-hades'>Black Hades</a></li> 
</ul> 
<li><a href='/loot?item=mage-plate'>Mage Plate</a></li> 
<ul><li><a href='/loot?item=que-hegans-wisdon'>Que-Hegan's Wisdon</a></li> 
</ul> 
<li><a href='/loot?item=embossed-plate'>Embossed Plate</a></li> 
<ul><li><a href='/loot?item=atmas-wail'>Atma's Wail</a></li> 
</ul> 
<li><a href='/loot?item=sharktooth-armor'>Sharktooth Armor</a></li> 
<ul><li><a href='/loot?item=toothrow'>Toothrow</a></li> 
</ul> 
<li><a href='/loot?item=templar-coat'>Templar Coat</a></li> 
<ul><li><a href='/loot?item=guardian-angel'>Guardian Angel</a></li> 
</ul> 
<li><a href='/loot?item=russet-armor'>Russet Armor</a></li> 
<ul><li><a href='/loot?item=skullders-ire'>Skullder's Ire</a></li> 
</ul> 
<li><a href='/loot?item=cuirass'>Cuirass</a></li> 
<ul><li><a href='/loot?item=duriels-shell'>Duriel's Shell</a></li> 
</ul> 
<li><a href='/loot?item=mesh-armor'>Mesh Armor</a></li> 
<ul><li><a href='/loot?item=shaftstop'>Shaftstop</a></li> 
</ul> 
<li><a href='/loot?item=tigulated-mail'>Tigulated Mail</a></li> 
<ul><li><a href='/loot?item=crow-caw'>Crow Caw</a></li> 
</ul> 
<li><a href='/loot?item=linked-mail'>Linked Mail</a></li> 
<ul><li><a href='/loot?item=spiritforge'>Spiritforge</a></li> 
</ul> 
<li><a href='/loot?item=trellised-armor'>Trellised Armor</a></li> 
<ul><li><a href='/loot?item=ironpelt'>Ironpelt</a></li> 
</ul> 
<li><a href='/loot?item=ancient-armor'>Ancient Armor</a></li> 
<ul><li><a href='/loot?item=victors-silk'>Victors Silk</a></li> 
</ul> 
<li><a href='/loot?item=full-plate-mail'>Full Plate Mail</a></li> 
<ul><li><a href='/loot?item=goldskin'>Goldskin</a></li> 
</ul> 
<li><a href='/loot?item=demonhide-armor'>Demonhide Armor</a></li> 
<ul><li><a href='/loot?item=skin-of-the-flayerd-one'>Skin Of The Flayerd One</a></li> 
</ul> 
<li><a href='/loot?item=serpentskin-armor'>Serpentskin Armor</a></li> 
<ul><li><a href='/loot?item=skin-of-the-vipermagi'>Skin Of The Vipermagi</a></li> 
</ul> 
<li><a href='/loot?item=light-plate'>Light Plate</a></li> 
<ul><li><a href='/loot?item=heavenly-garb'>Heavenly Garb</a></li> 
</ul> 
<li><a href='/loot?item=ghost-armor'>Ghost Armor</a></li> 
<ul><li><a href='/loot?item=the-spirit-shroud'>The Spirit Shroud</a></li> 
</ul> 
<li><a href='/loot?item=gothic-plate'>Gothic Plate</a></li> 
<ul><li><a href='/loot?item=rattlecage'>Rattlecage</a></li> 
</ul> 
<li><a href='/loot?item=field-plate'>Field Plate</a></li> 
<ul><li><a href='/loot?item=rockfleece'>Rockfleece</a></li> 
</ul> 
<li><a href='/loot?item=plate-mail'>Plate Mail</a></li> 
<ul><li><a href='/loot?item=boneflesh'>Boneflesh</a></li> 
</ul> 
<li><a href='/loot?item=splint-mail'>Splint Mail</a></li> 
<ul><li><a href='/loot?item=iceblink'>Iceblink</a></li> 
</ul> 
<li><a href='/loot?item=breast-plate'>Breast Plate</a></li> 
<ul><li><a href='/loot?item=venomsward'>Venomsward</a></li> 
</ul> 
<li><a href='/loot?item=chain-mail'>Chain Mail</a></li> 
<ul><li><a href='/loot?item=sparking-mail'>Sparking Mail</a></li> 
</ul> 
<li><a href='/loot?item=scale-mail'>Scale Mail</a></li> 
<ul><li><a href='/loot?item=hawkmail'>Hawkmail</a></li> 
</ul> 
<li><a href='/loot?item=ring-mail'>Ring Mail</a></li> 
<ul><li><a href='/loot?item=darkglow'>Darkglow</a></li> 
</ul> 
<li><a href='/loot?item=studded-leather-'>Studded Leather </a></li> 
<ul><li><a href='/loot?item=twitchthroe'>Twitchthroe</a></li> 
</ul> 
<li><a href='/loot?item=hard-leather-armor'>Hard Leather Armor</a></li> 
<ul><li><a href='/loot?item=the-centurion'>The Centurion</a></li> 
</ul> 
<li><a href='/loot?item=leather-armor'>Leather Armor</a></li> 
<ul><li><a href='/loot?item=blinkbats-form'>Blinkbats Form</a></li> 
</ul> 
<li><a href='/loot?item=quilted-armor'>Quilted Armor</a></li> 
<ul><li><a href='/loot?item=greyform'>Greyform</a></li> 
</ul> 
</ul> 
<li>Circlet</li> 
<ul><li><a href='/loot?item=diadem'>Diadem</a></li> 
<ul><li><a href='/loot?item=griffons-eye'>Griffon's Eye</a></li> 
</ul> 
<li><a href='/loot?item=tiara'>Tiara</a></li> 
<ul><li><a href='/loot?item=kiras-guardian'>Kira's Guardian</a></li> 
</ul> 
<li><a href='/loot?item=coronet'>Coronet</a></li> 
<li><a href='/loot?item=circlet'>Circlet</a></li> 
</ul> 
<li>Druid Pelt</li> 
<ul><li><a href='/loot?item=dream-spirit'>Dream Spirit</a></li> 
<ul><li><a href='/loot?item=jalals-mane'>Jalal's Mane</a></li> 
</ul> 
<li><a href='/loot?item=sky-spirit'>Sky Spirit</a></li> 
<ul><li><a href='/loot?item=ravenlore'>Ravenlore</a></li> 
</ul> 
<li><a href='/loot?item=earth-spirit'>Earth Spirit</a></li> 
<ul><li><a href='/loot?item=spiritkeeper'>Spiritkeeper</a></li> 
</ul> 
<li><a href='/loot?item=sun-spirit'>Sun Spirit</a></li> 
<li><a href='/loot?item=blood-spirit'>Blood Spirit</a></li> 
<ul><li><a href='/loot?item=cerebus'>Cerebus</a></li> 
</ul> 
<li><a href='/loot?item=totemic-mask'>Totemic Mask</a></li> 
<li><a href='/loot?item=sacred-feathers'>Sacred Feathers</a></li> 
<li><a href='/loot?item=hunters-guise'>Hunter's Guise</a></li> 
<li><a href='/loot?item=griffon-headress'>Griffon Headress</a></li> 
<li><a href='/loot?item=alpha-helm'>Alpha Helm</a></li> 
<li><a href='/loot?item=spirit-mask'>Spirit Mask</a></li> 
<li><a href='/loot?item=falcon-mask'>Falcon Mask</a></li> 
<li><a href='/loot?item=antlers'>Antlers</a></li> 
<li><a href='/loot?item=hawk-helm'>Hawk Helm</a></li> 
<li><a href='/loot?item=wolf-head'>Wolf Head</a></li> 
</ul> 
<li>Gloves</li> 
<ul><li><a href='/loot?item=ogre-gauntlets'>Ogre Gauntlets</a></li> 
<ul><li><a href='/loot?item=steelrend'>Steelrend</a></li> 
</ul> 
<li><a href='/loot?item=crusader-gauntlets'>Crusader Gauntlets</a></li> 
<li><a href='/loot?item=vambraces'>Vambraces</a></li> 
<ul><li><a href='/loot?item=souldrain'>Souldrain</a></li> 
</ul> 
<li><a href='/loot?item=vampirebone-gloves'>Vampirebone Gloves</a></li> 
<ul><li><a href='/loot?item=draculs-grasp'>Dracul's Grasp</a></li> 
</ul> 
<li><a href='/loot?item=bramble-mitts'>Bramble Mitts</a></li> 
<li><a href='/loot?item=war-gauntlets'>War Gauntlets</a></li> 
<ul><li><a href='/loot?item=hellmouth'>Hellmouth</a></li> 
</ul> 
<li><a href='/loot?item=battle-gauntlets'>Battle Gauntlets</a></li> 
<ul><li><a href='/loot?item=lavagout'>Lavagout</a></li> 
</ul> 
<li><a href='/loot?item=heavy-bracers'>Heavy Bracers</a></li> 
<ul><li><a href='/loot?item=ghoulhide'>Ghoulhide</a></li> 
</ul> 
<li><a href='/loot?item=sharkskin-gloves'>Sharkskin Gloves</a></li> 
<ul><li><a href='/loot?item=gravepalm'>Gravepalm</a></li> 
</ul> 
<li><a href='/loot?item=demonhide-gloves'>Demonhide Gloves</a></li> 
<ul><li><a href='/loot?item=venom-grip'>Venom Grip</a></li> 
</ul> 
<li><a href='/loot?item=gauntlets'>Gauntlets</a></li> 
<ul><li><a href='/loot?item=frostburn'>Frostburn</a></li> 
</ul> 
<li><a href='/loot?item=light-gauntlets'>Light Gauntlets</a></li> 
<ul><li><a href='/loot?item=magefist'>Magefist</a></li> 
</ul> 
<li><a href='/loot?item=bracers'>Bracers</a></li> 
<ul><li><a href='/loot?item=chance-guards'>Chance Guards</a></li> 
</ul> 
<li><a href='/loot?item=heavy-gloves'>Heavy Gloves</a></li> 
<ul><li><a href='/loot?item=bloodfist'>Bloodfist</a></li> 
</ul> 
<li><a href='/loot?item=gloves'>Gloves</a></li> 
<ul><li><a href='/loot?item=the-hand-of-broc'>The Hand Of Broc</a></li> 
</ul> 
</ul> 
<li>Helm</li> 
<ul><li><a href='/loot?item=corona'>Corona</a></li> 
<ul><li><a href='/loot?item=crown-of-ages'>Crown Of Ages</a></li> 
</ul> 
<li><a href='/loot?item=bone-visage'>Bone Visage</a></li> 
<ul><li><a href='/loot?item=giantskull'>Giantskull</a></li> 
</ul> 
<li><a href='/loot?item=spired-helm'>Spired Helm</a></li> 
<ul><li><a href='/loot?item=veil-of-steel'>Veil Of Steel</a></li> 
<li><a href='/loot?item=nightwings-veil'>Nightwing's Veil</a></li> 
</ul> 
<li><a href='/loot?item=demonhead'>Demonhead</a></li> 
<ul><li><a href='/loot?item=andariels-visage'>Andariel's Visage</a></li> 
</ul> 
<li><a href='/loot?item=armet'>Armet</a></li> 
<ul><li><a href='/loot?item=steelshade'>Steelshade</a></li> 
</ul> 
<li><a href='/loot?item=hydraskull'>Hydraskull</a></li> 
<li><a href='/loot?item=shako'>Shako</a></li> 
<ul><li><a href='/loot?item=harlequin-crest'>Harlequin Crest</a></li> 
</ul> 
<li><a href='/loot?item=grand-crown'>Grand Crown</a></li> 
<ul><li><a href='/loot?item=crown-of-thieves'>Crown Of Thieves</a></li> 
</ul> 
<li><a href='/loot?item=giant-conch'>Giant Conch</a></li> 
<li><a href='/loot?item=winged-helm'>Winged Helm</a></li> 
<ul><li><a href='/loot?item=valkiry-wing'>Valkiry Wing</a></li> 
</ul> 
<li><a href='/loot?item=grim-helm'>Grim Helm</a></li> 
<ul><li><a href='/loot?item=vampiregaze'>Vampiregaze</a></li> 
</ul> 
<li><a href='/loot?item=death-mask'>Death Mask</a></li> 
<ul><li><a href='/loot?item=blackhorns-face'>Blackhorn's Face</a></li> 
</ul> 
<li><a href='/loot?item=basinet'>Basinet</a></li> 
<ul><li><a href='/loot?item=darksight-helm'>Darksight Helm</a></li> 
</ul> 
<li><a href='/loot?item=casque'>Casque</a></li> 
<ul><li><a href='/loot?item=stealskull'>Stealskull</a></li> 
</ul> 
<li><a href='/loot?item=sallet'>Sallet</a></li> 
<ul><li><a href='/loot?item=rockstopper'>Rockstopper</a></li> 
</ul> 
<li><a href='/loot?item=war-hat'>War Hat</a></li> 
<ul><li><a href='/loot?item=peasent-crown'>Peasent Crown</a></li> 
</ul> 
<li><a href='/loot?item=crown'>Crown</a></li> 
<ul><li><a href='/loot?item=undead-crown'>Undead Crown</a></li> 
</ul> 
<li><a href='/loot?item=great-helm'>Great Helm</a></li> 
<ul><li><a href='/loot?item=howltusk'>Howltusk</a></li> 
</ul> 
<li><a href='/loot?item=bone-helm'>Bone Helm</a></li> 
<ul><li><a href='/loot?item=wormskull'>Wormskull</a></li> 
</ul> 
<li><a href='/loot?item=mask'>Mask</a></li> 
<ul><li><a href='/loot?item=the-face-of-horror'>The Face Of Horror</a></li> 
</ul> 
<li><a href='/loot?item=full-helm'>Full Helm</a></li> 
<ul><li><a href='/loot?item=duskdeep'>Duskdeep</a></li> 
</ul> 
<li><a href='/loot?item=Helm'>Helm</a></li> 
<ul><li><a href='/loot?item=coif-of-glory'>Coif Of Glory</a></li> 
</ul> 
<li><a href='/loot?item=skull-cap'>Skull Cap</a></li> 
<ul><li><a href='/loot?item=tarnhelm'>Tarnhelm</a></li> 
</ul> 
<li><a href='/loot?item=cap'>Cap</a></li> 
<ul><li><a href='/loot?item=war-bonnet'>War Bonnet</a></li> 
</ul> 
</ul> 
<li>Necromancer Head</li> 
<ul><li><a href='/loot?item=bloodlord-skull'>Bloodlord Skull</a></li> 
<ul><li><a href='/loot?item=darkforge-spawn'>Darkforge Spawn</a></li> 
</ul> 
<li><a href='/loot?item=succubae-skull'>Succubae Skull</a></li> 
<ul><li><a href='/loot?item=boneflame'>Boneflame</a></li> 
</ul> 
<li><a href='/loot?item=hellspawn-skull'>Hellspawn Skull</a></li> 
<li><a href='/loot?item=overseer-skull'>Overseer Skull</a></li> 
<li><a href='/loot?item=minion-skull'>Minion Skull</a></li> 
<li><a href='/loot?item=heirophant-trophy'>Heirophant Trophy</a></li> 
<ul><li><a href='/loot?item=homunculus'>Homunculus</a></li> 
</ul> 
<li><a href='/loot?item=cantor-trophy'>Cantor Trophy</a></li> 
<li><a href='/loot?item=sexton-trophy'>Sexton Trophy</a></li> 
<li><a href='/loot?item=fetish-trophy'>Fetish Trophy</a></li> 
<li><a href='/loot?item=mummified-trophy'>Mummified Trophy</a></li> 
<li><a href='/loot?item=demon-head'>Demon Head</a></li> 
<li><a href='/loot?item=gargoyle-head'>Gargoyle Head</a></li> 
<li><a href='/loot?item=unraveller-head'>Unraveller Head</a></li> 
<li><a href='/loot?item=zombie-head'>Zombie Head</a></li> 
<li><a href='/loot?item=preserved-head'>Preserved Head</a></li> 
</ul> 
<li>Paladin Shield</li> 
<ul><li><a href='/loot?item=vortex-shield'>Vortex Shield</a></li> 
<li><a href='/loot?item=zakarum-shield'>Zakarum Shield</a></li> 
<ul><li><a href='/loot?item=dragonscale'>Dragonscale</a></li> 
</ul> 
<li><a href='/loot?item=sacred-rondache'>Sacred Rondache</a></li> 
<ul><li><a href='/loot?item=alma-negra'>Alma Negra</a></li> 
</ul> 
<li><a href='/loot?item=sacred-targe'>Sacred Targe</a></li> 
<li><a href='/loot?item=royal-shield'>Royal Shield</a></li> 
<li><a href='/loot?item=guilded-shield'>Guilded Shield</a></li> 
<li><a href='/loot?item=protector-shield'>Protector Shield</a></li> 
<li><a href='/loot?item=akaran-rondache'>Akaran Rondache</a></li> 
<li><a href='/loot?item=akaran-targe'>Akaran Targe</a></li> 
<li><a href='/loot?item=crown-shield'>Crown Shield</a></li> 
<li><a href='/loot?item=aerin-shield'>Aerin Shield</a></li> 
<ul><li><a href='/loot?item=herald-of-zakarum'>Herald Of Zakarum</a></li> 
</ul> 
<li><a href='/loot?item=heraldic-shield'>Heraldic Shield</a></li> 
<li><a href='/loot?item=rondache'>Rondache</a></li> 
<li><a href='/loot?item=targe'>Targe</a></li> 
</ul> 
<li>Shield</li> 
<ul><li><a href='/loot?item=ward'>Ward</a></li> 
<ul><li><a href='/loot?item=spirit-ward'>Spirit Ward</a></li> 
</ul> 
<li><a href='/loot?item=aegis'>Aegis</a></li> 
<ul><li><a href='/loot?item=medusas-gaze'>Medusa's Gaze</a></li> 
</ul> 
<li><a href='/loot?item=troll-nest'>Troll Nest</a></li> 
<ul><li><a href='/loot?item=headhunters-glory'>Headhunter's Glory</a></li> 
</ul> 
<li><a href='/loot?item=monarch'>Monarch</a></li> 
<ul><li><a href='/loot?item=stormshield'>Stormshield</a></li> 
</ul> 
<li><a href='/loot?item=blade-barrier'>Blade Barrier</a></li> 
<ul><li><a href='/loot?item=spike-thorn'>Spike Thorn</a></li> 
</ul> 
<li><a href='/loot?item=hyperion'>Hyperion</a></li> 
<li><a href='/loot?item=luna'>Luna</a></li> 
<ul><li><a href='/loot?item=blackoak-shield'>Blackoak Shield</a></li> 
</ul> 
<li><a href='/loot?item=heater'>Heater</a></li> 
<li><a href='/loot?item=ancient-shield'>Ancient Shield</a></li> 
<ul><li><a href='/loot?item=radimants-sphere'>Radimant's Sphere</a></li> 
</ul> 
<li><a href='/loot?item=pavise'>Pavise</a></li> 
<ul><li><a href='/loot?item=kerkes-sanctuary'>Kerke's Sanctuary</a></li> 
</ul> 
<li><a href='/loot?item=grim-shield'>Grim Shield</a></li> 
<ul><li><a href='/loot?item=lidless-wall'>Lidless Wall</a></li> 
</ul> 
<li><a href='/loot?item=dragon-shield'>Dragon Shield</a></li> 
<ul><li><a href='/loot?item=tiamats-rebuke'>Tiamat's Rebuke</a></li> 
</ul> 
<li><a href='/loot?item=barbed-shield'>Barbed Shield</a></li> 
<ul><li><a href='/loot?item=lance-guard'>Lance Guard</a></li> 
</ul> 
<li><a href='/loot?item=scutum'>Scutum</a></li> 
<ul><li><a href='/loot?item=stormchaser'>Stormchaser</a></li> 
</ul> 
<li><a href='/loot?item=round-shield'>Round Shield</a></li> 
<ul><li><a href='/loot?item=mosers-blessed-circle'>Mosers Blessed Circle</a></li> 
</ul> 
<li><a href='/loot?item=defender'>Defender</a></li> 
<ul><li><a href='/loot?item=visceratuant'>Visceratuant</a></li> 
</ul> 
<li><a href='/loot?item=gothic-shield'>Gothic Shield</a></li> 
<ul><li><a href='/loot?item=the-ward'>The Ward</a></li> 
</ul> 
<li><a href='/loot?item=tower-shield'>Tower Shield</a></li> 
<ul><li><a href='/loot?item=bverrit-keep'>Bverrit Keep</a></li> 
</ul> 
<li><a href='/loot?item=bone-shield'>Bone Shield</a></li> 
<ul><li><a href='/loot?item=wall-of-the-eyeless'>Wall Of The Eyeless</a></li> 
</ul> 
<li><a href='/loot?item=kite-shield'>Kite Shield</a></li> 
<ul><li><a href='/loot?item=steelclash'>Steelclash</a></li> 
</ul> 
<li><a href='/loot?item=spiked-shield'>Spiked Shield</a></li> 
<ul><li><a href='/loot?item=swordback-hold'>Swordback Hold</a></li> 
</ul> 
<li><a href='/loot?item=large-shield'>Large Shield</a></li> 
<ul><li><a href='/loot?item=stormguild'>Stormguild</a></li> 
</ul> 
<li><a href='/loot?item=small-shield'>Small Shield</a></li> 
<ul><li><a href='/loot?item=umbral-disk'>Umbral Disk</a></li> 
</ul> 
<li><a href='/loot?item=buckler'>Buckler</a></li> 
<ul><li><a href='/loot?item=pelta-lunata'>Pelta Lunata</a></li> 
</ul> 
</ul> 
</ul> 
<li>Disposable</li> 
<ul><li>Potion</li> 
<li>Scroll</li> 
<li>Tome</li> 
</ul> 
<li>Weapon</li> 
<ul><li>2 Handed Assassin Katar</li> 
<ul><li><a href='/loot?item=scissors-suwayyah'>Scissors Suwayyah</a></li> 
<li><a href='/loot?item=runic-talons'>Runic Talons</a></li> 
<ul><li><a href='/loot?item=cutthroat'>Cutthroat</a></li> 
</ul> 
<li><a href='/loot?item=feral-claws'>Feral Claws</a></li> 
<ul><li><a href='/loot?item=firelizards-talons'>Firelizard's Talons</a></li> 
</ul> 
<li><a href='/loot?item=battle-cestus'>Battle Cestus</a></li> 
<ul><li><a href='/loot?item=shadowkiller'>Shadowkiller</a></li> 
</ul> 
<li><a href='/loot?item=war-fist'>War Fist</a></li> 
<li><a href='/loot?item=wrist-sword'>Wrist Sword</a></li> 
<ul><li><a href='/loot?item=jadetalon'>Jadetalon</a></li> 
</ul> 
<li><a href='/loot?item=suwayyah'>Suwayyah</a></li> 
<li><a href='/loot?item=scissors-quhab'>Scissors Quhab</a></li> 
<li><a href='/loot?item=greater-talons'>Greater Talons</a></li> 
<li><a href='/loot?item=greater-claws'>Greater Claws</a></li> 
<li><a href='/loot?item=hand-scythe'>Hand Scythe</a></li> 
</ul> 
<li>Amazon Bow</li> 
<ul><li><a href='/loot?item=grand-matron-bow'>Grand Matron Bow</a></li> 
<li><a href='/loot?item=matriarchal-bow'>Matriarchal Bow</a></li> 
<ul><li><a href='/loot?item=bloodravens-charge'>Bloodraven's Charge</a></li> 
</ul> 
<li><a href='/loot?item=ceremonial-bow'>Ceremonial Bow</a></li> 
<ul><li><a href='/loot?item=lycanders-aim'>Lycander's Aim</a></li> 
</ul> 
<li><a href='/loot?item=ashwood-bow'>Ashwood Bow</a></li> 
<li><a href='/loot?item=reflex-bow'>Reflex Bow</a></li> 
<li><a href='/loot?item=stag-bow'>Stag Bow</a></li> 
</ul> 
<li>Amazon Javelin</li> 
<ul><li><a href='/loot?item=matriarchal-javelin'>Matriarchal Javelin</a></li> 
<ul><li><a href='/loot?item=thunderstroke'>Thunderstroke</a></li> 
</ul> 
<li><a href='/loot?item=ceremonial-javelin'>Ceremonial Javelin</a></li> 
<ul><li><a href='/loot?item=titans-revenge'>Titan's Revenge</a></li> 
</ul> 
<li><a href='/loot?item=maiden-javelin'>Maiden Javelin</a></li> 
</ul> 
<li>Amazon Spear</li> 
<ul><li><a href='/loot?item=matriarchal-pike'>Matriarchal Pike</a></li> 
<li><a href='/loot?item=matriarchal-spear'>Matriarchal Spear</a></li> 
<ul><li><a href='/loot?item=stoneraven'>Stoneraven</a></li> 
</ul> 
<li><a href='/loot?item=ceremonial-pike'>Ceremonial Pike</a></li> 
<ul><li><a href='/loot?item=lycanders-flank'>Lycander's Flank</a></li> 
</ul> 
<li><a href='/loot?item=ceremonial-spear'>Ceremonial Spear</a></li> 
<li><a href='/loot?item=maiden-pike'>Maiden Pike</a></li> 
<li><a href='/loot?item=maiden-spear'>Maiden Spear</a></li> 
</ul> 
<li>Assassin Katar</li> 
<ul><li><a href='/loot?item=fascia'>Fascia</a></li> 
<li><a href='/loot?item=wrist-spike'>Wrist Spike</a></li> 
<li><a href='/loot?item=quhab'>Quhab</a></li> 
<li><a href='/loot?item=scissors-katar'>Scissors Katar</a></li> 
<li><a href='/loot?item=blade-talons'>Blade Talons</a></li> 
<li><a href='/loot?item=claws'>Claws</a></li> 
<li><a href='/loot?item=cestus'>Cestus</a></li> 
<li><a href='/loot?item=hatchet-hands'>Hatchet Hands</a></li> 
<li><a href='/loot?item=wrist-blade'>Wrist Blade</a></li> 
<li><a href='/loot?item=katar'>Katar</a></li> 
</ul> 
<li>Axe</li> 
<ul><li><a href='/loot?item=glorious-axe'>Glorious Axe</a></li> 
<ul><li><a href='/loot?item=executioners-justice'>Executioner's Justice</a></li> 
</ul> 
<li><a href='/loot?item=berserker-axe'>Berserker Axe</a></li> 
<ul><li><a href='/loot?item=deathcleaver'>Deathcleaver</a></li> 
</ul> 
<li><a href='/loot?item=champion-axe'>Champion Axe</a></li> 
<ul><li><a href='/loot?item=messerschmidts-reaver'>Messerschmidt's Reaver</a></li> 
</ul> 
<li><a href='/loot?item=war-spike'>War Spike</a></li> 
<ul><li><a href='/loot?item=cranebeak'>Cranebeak</a></li> 
</ul> 
<li><a href='/loot?item=decapitator'>Decapitator</a></li> 
<ul><li><a href='/loot?item=hellslayer'>Hellslayer</a></li> 
</ul> 
<li><a href='/loot?item=ettin-axe'>Ettin Axe</a></li> 
<ul><li><a href='/loot?item=runemaster'>Runemaster</a></li> 
</ul> 
<li><a href='/loot?item=silver-edged-axe'>Silver Edged Axe</a></li> 
<ul><li><a href='/loot?item=ethereal-edge'>Ethereal Edge</a></li> 
</ul> 
<li><a href='/loot?item=small-crescent'>Small Crescent</a></li> 
<li><a href='/loot?item=feral-axe'>Feral Axe</a></li> 
<li><a href='/loot?item=tomahawk'>Tomahawk</a></li> 
<ul><li><a href='/loot?item=razoredge'>Razoredge</a></li> 
</ul> 
<li><a href='/loot?item=ancient-axe'>Ancient Axe</a></li> 
<ul><li><a href='/loot?item=the-minataur'>The Minataur</a></li> 
</ul> 
<li><a href='/loot?item=naga'>Naga</a></li> 
<ul><li><a href='/loot?item=guardian-naga'>Guardian Naga</a></li> 
</ul> 
<li><a href='/loot?item=gothic-axe'>Gothic Axe</a></li> 
<ul><li><a href='/loot?item=boneslayer-blade'>Boneslayer Blade</a></li> 
</ul> 
<li><a href='/loot?item=crowbill'>Crowbill</a></li> 
<ul><li><a href='/loot?item=pompes-wrath'>Pompe's Wrath</a></li> 
</ul> 
<li><a href='/loot?item=tabar'>Tabar</a></li> 
<ul><li><a href='/loot?item=stormrider'>Stormrider</a></li> 
</ul> 
<li><a href='/loot?item=twin-axe'>Twin Axe</a></li> 
<ul><li><a href='/loot?item=islestrike'>Islestrike</a></li> 
</ul> 
<li><a href='/loot?item=bearded-axe-'>Bearded Axe </a></li> 
<ul><li><a href='/loot?item=spellsteel'>Spellsteel</a></li> 
</ul> 
<li><a href='/loot?item=military-axe'>Military Axe</a></li> 
<ul><li><a href='/loot?item=warlords-trust'>Warlord's Trust</a></li> 
</ul> 
<li><a href='/loot?item=cleaver'>Cleaver</a></li> 
<ul><li><a href='/loot?item=butchers-pupil'>Butcher's Pupil</a></li> 
</ul> 
<li><a href='/loot?item=hatchet'>Hatchet</a></li> 
<ul><li><a href='/loot?item=coldkill'>Coldkill</a></li> 
</ul> 
<li><a href='/loot?item=giant-axe'>Giant Axe</a></li> 
<ul><li><a href='/loot?item=the-humongous'>The Humongous</a></li> 
</ul> 
<li><a href='/loot?item=war-axe'>War Axe</a></li> 
<ul><li><a href='/loot?item=rakescar'>Rakescar</a></li> 
</ul> 
<li><a href='/loot?item=great-axe'>Great Axe</a></li> 
<ul><li><a href='/loot?item=brainhew'>Brainhew</a></li> 
</ul> 
<li><a href='/loot?item=military-pick'>Military Pick</a></li> 
<ul><li><a href='/loot?item=mindrend'>Mindrend</a></li> 
</ul> 
<li><a href='/loot?item=battle-axe'>Battle Axe</a></li> 
<ul><li><a href='/loot?item=the-chieftan'>The Chieftan</a></li> 
</ul> 
<li><a href='/loot?item=double-axe'>Double Axe</a></li> 
<ul><li><a href='/loot?item=bladebone'>Bladebone</a></li> 
</ul> 
<li><a href='/loot?item=broad-axe-'>Broad Axe </a></li> 
<ul><li><a href='/loot?item=goreshovel'>Goreshovel</a></li> 
</ul> 
<li><a href='/loot?item=axe'>Axe</a></li> 
<ul><li><a href='/loot?item=deathspade'>Deathspade</a></li> 
</ul> 
<li><a href='/loot?item=large-axe'>Large Axe</a></li> 
<ul><li><a href='/loot?item=fechmars-axe'>Fechmars Axe</a></li> 
</ul> 
<li><a href='/loot?item=hand-axe'>Hand Axe</a></li> 
<ul><li><a href='/loot?item=the-gnasher'>The Gnasher</a></li> 
</ul> 
</ul> 
<li>Bow</li> 
<ul><li><a href='/loot?item=hydra-bow'>Hydra Bow</a></li> 
<ul><li><a href='/loot?item=windforce'>Windforce</a></li> 
</ul> 
<li><a href='/loot?item=ward-bow'>Ward Bow</a></li> 
<ul><li><a href='/loot?item=widowmaker'>Widowmaker</a></li> 
</ul> 
<li><a href='/loot?item=crusader-bow'>Crusader Bow</a></li> 
<ul><li><a href='/loot?item=eaglehorn'>Eaglehorn</a></li> 
</ul> 
<li><a href='/loot?item=diamond-bow'>Diamond Bow</a></li> 
<li><a href='/loot?item=great-bow'>Great Bow</a></li> 
<li><a href='/loot?item=shadow-bow'>Shadow Bow</a></li> 
<li><a href='/loot?item=blade-bow'>Blade Bow</a></li> 
<li><a href='/loot?item=spider-bow'>Spider Bow</a></li> 
<li><a href='/loot?item=gothic-bow'>Gothic Bow</a></li> 
<ul><li><a href='/loot?item=godstrike-arch'>Godstrike Arch</a></li> 
</ul> 
<li><a href='/loot?item=rune-bow'>Rune Bow</a></li> 
<ul><li><a href='/loot?item=magewrath'>Magewrath</a></li> 
</ul> 
<li><a href='/loot?item=long-siege-bow'>Long Siege Bow</a></li> 
<ul><li><a href='/loot?item=cliffkiller'>Cliffkiller</a></li> 
</ul> 
<li><a href='/loot?item=short-siege-bow'>Short Siege Bow</a></li> 
<ul><li><a href='/loot?item=whichwild-string'>Whichwild String</a></li> 
</ul> 
<li><a href='/loot?item=double-bow'>Double Bow</a></li> 
<ul><li><a href='/loot?item=endlesshail'>Endlesshail</a></li> 
</ul> 
<li><a href='/loot?item=cedar-bow'>Cedar Bow</a></li> 
<ul><li><a href='/loot?item=kuko-shakaku'>Kuko Shakaku</a></li> 
</ul> 
<li><a href='/loot?item=razor-bow'>Razor Bow</a></li> 
<ul><li><a href='/loot?item=riphook'>Riphook</a></li> 
</ul> 
<li><a href='/loot?item=long-war-bow'>Long War Bow</a></li> 
<ul><li><a href='/loot?item=blastbark'>Blastbark</a></li> 
</ul> 
<li><a href='/loot?item=edge-bow'>Edge Bow</a></li> 
<ul><li><a href='/loot?item=skystrike'>Skystrike</a></li> 
</ul> 
<li><a href='/loot?item=short-war-bow'>Short War Bow</a></li> 
<ul><li><a href='/loot?item=hellclap'>Hellclap</a></li> 
</ul> 
<li><a href='/loot?item=long-battle-bow'>Long Battle Bow</a></li> 
<ul><li><a href='/loot?item=wizendraw'>Wizendraw</a></li> 
</ul> 
<li><a href='/loot?item=short-battle-bow'>Short Battle Bow</a></li> 
<ul><li><a href='/loot?item=pullspite'>Pullspite</a></li> 
</ul> 
<li><a href='/loot?item=composite-bow'>Composite Bow</a></li> 
<ul><li><a href='/loot?item=piercerib'>Piercerib</a></li> 
</ul> 
<li><a href='/loot?item=long-bow'>Long Bow</a></li> 
<ul><li><a href='/loot?item=rimeraven'>Rimeraven</a></li> 
</ul> 
<li><a href='/loot?item=hunters-bow'>Hunter's Bow</a></li> 
<ul><li><a href='/loot?item=witherstring'>Witherstring</a></li> 
</ul> 
<li><a href='/loot?item=short-bow'>Short Bow</a></li> 
<ul><li><a href='/loot?item=pluckeye'>Pluckeye</a></li> 
</ul> 
</ul> 
<li>Club</li> 
<ul><li><a href='/loot?item=tyrant-club'>Tyrant Club</a></li> 
<ul><li><a href='/loot?item=demonlimb'>Demonlimb</a></li> 
</ul> 
<li><a href='/loot?item=truncheon'>Truncheon</a></li> 
<ul><li><a href='/loot?item=nords-tenderizer'>Nord's Tenderizer</a></li> 
</ul> 
<li><a href='/loot?item=barbed-club'>Barbed Club</a></li> 
<ul><li><a href='/loot?item=fleshrender'>Fleshrender</a></li> 
</ul> 
<li><a href='/loot?item=cudgel'>Cudgel</a></li> 
<ul><li><a href='/loot?item=dark-clan-crusher'>Dark Clan Crusher</a></li> 
</ul> 
<li><a href='/loot?item=spiked-club'>Spiked Club</a></li> 
<ul><li><a href='/loot?item=stoutnail'>Stoutnail</a></li> 
</ul> 
<li><a href='/loot?item=club'>Club</a></li> 
<ul><li><a href='/loot?item=felloak'>Felloak</a></li> 
</ul> 
<li><a href='/loot?item=wirts-leg'>Wirt's Leg</a></li> 
</ul> 
<li>Crossbow</li> 
<ul><li><a href='/loot?item=demon-crossbow'>Demon Crossbow</a></li> 
<ul><li><a href='/loot?item=gutsiphon'>Gutsiphon</a></li> 
</ul> 
<li><a href='/loot?item=colossus-crossbow'>Colossus Crossbow</a></li> 
<ul><li><a href='/loot?item=hellrack'>Hellrack</a></li> 
</ul> 
<li><a href='/loot?item=gorgon-crossbow'>Gorgon Crossbow</a></li> 
<li><a href='/loot?item=pellet-bow'>Pellet Bow</a></li> 
<li><a href='/loot?item=chu-ko-nu'>Chu-Ko-Nu</a></li> 
<ul><li><a href='/loot?item=demon-machine'>Demon Machine</a></li> 
</ul> 
<li><a href='/loot?item=balista'>Balista</a></li> 
<ul><li><a href='/loot?item=buriza-do-kyanon'>Buriza-Do Kyanon</a></li> 
</ul> 
<li><a href='/loot?item=siege-crossbow'>Siege Crossbow</a></li> 
<ul><li><a href='/loot?item=pus-spiter'>Pus Spiter</a></li> 
</ul> 
<li><a href='/loot?item=arbalest'>Arbalest</a></li> 
<ul><li><a href='/loot?item=langer-briser'>Langer Briser</a></li> 
</ul> 
<li><a href='/loot?item=repeating-crossbow'>Repeating Crossbow</a></li> 
<ul><li><a href='/loot?item=doomspittle'>Doomspittle</a></li> 
</ul> 
<li><a href='/loot?item=heavy-crossbow'>Heavy Crossbow</a></li> 
<ul><li><a href='/loot?item=hellcast'>Hellcast</a></li> 
</ul> 
<li><a href='/loot?item=crossbow'>Crossbow</a></li> 
<ul><li><a href='/loot?item=ichorsting'>Ichorsting</a></li> 
</ul> 
<li><a href='/loot?item=light-crossbow'>Light Crossbow</a></li> 
<ul><li><a href='/loot?item=leadcrow'>Leadcrow</a></li> 
</ul> 
</ul> 
<li>Hammer</li> 
<ul><li><a href='/loot?item=thunder-maul'>Thunder Maul</a></li> 
<ul><li><a href='/loot?item=the-cranium-basher'>The Cranium Basher</a></li> 
<li><a href='/loot?item=earthshifter'>Earthshifter</a></li> 
</ul> 
<li><a href='/loot?item=legendary-mallet'>Legendary Mallet</a></li> 
<ul><li><a href='/loot?item=schaefers-hammer'>Schaefer's Hammer</a></li> 
<li><a href='/loot?item=stone-crusher'>Stone Crusher</a></li> 
</ul> 
<li><a href='/loot?item=ogre-maul'>Ogre Maul</a></li> 
<ul><li><a href='/loot?item=windhammer'>Windhammer</a></li> 
</ul> 
<li><a href='/loot?item=martel-de-fer'>Martel De Fer</a></li> 
<ul><li><a href='/loot?item=the-gavel-of-pain'>The Gavel Of Pain</a></li> 
</ul> 
<li><a href='/loot?item=battle-hammer'>Battle Hammer</a></li> 
<ul><li><a href='/loot?item=earthshaker'>Earthshaker</a></li> 
</ul> 
<li><a href='/loot?item=war-club'>War Club</a></li> 
<ul><li><a href='/loot?item=bloodtree-stump'>Bloodtree Stump</a></li> 
</ul> 
<li><a href='/loot?item=great-maul'>Great Maul</a></li> 
<ul><li><a href='/loot?item=steeldriver'>Steeldriver</a></li> 
</ul> 
<li><a href='/loot?item=war-hammer'>War Hammer</a></li> 
<ul><li><a href='/loot?item=ironstone'>Ironstone</a></li> 
</ul> 
<li><a href='/loot?item=maul'>Maul</a></li> 
<ul><li><a href='/loot?item=bonesob'>Bonesob</a></li> 
</ul> 
<li><a href='/loot?item=horadric-malus'>Horadric Malus</a></li> 
</ul> 
<li>Javelin</li> 
<ul><li><a href='/loot?item=winged-harpoon'>Winged Harpoon</a></li> 
<ul><li><a href='/loot?item=gargoyles-bite'>Gargoyle's Bite</a></li> 
</ul> 
<li><a href='/loot?item=ghost-glaive'>Ghost Glaive</a></li> 
<ul><li><a href='/loot?item=wraithflight'>Wraithflight</a></li> 
</ul> 
<li><a href='/loot?item=balrog-spear'>Balrog Spear</a></li> 
<ul><li><a href='/loot?item=demons-arch'>Demon's Arch</a></li> 
</ul> 
<li><a href='/loot?item=stygian-pilum'>Stygian Pilum</a></li> 
<li><a href='/loot?item=hyperion-javelin'>Hyperion Javelin</a></li> 
<li><a href='/loot?item=harpoon'>Harpoon</a></li> 
<li><a href='/loot?item=spiculum'>Spiculum</a></li> 
<li><a href='/loot?item=simbilan'>Simbilan</a></li> 
<li><a href='/loot?item=great-pilum'>Great Pilum</a></li> 
<li><a href='/loot?item=war-javelin'>War Javelin</a></li> 
<li><a href='/loot?item=throwing-spear'>Throwing Spear</a></li> 
<li><a href='/loot?item=glaive'>Glaive</a></li> 
<li><a href='/loot?item=short-spear'>Short Spear</a></li> 
<li><a href='/loot?item=pilum'>Pilum</a></li> 
<li><a href='/loot?item=javelin'>Javelin</a></li> 
</ul> 
<li>Knife</li> 
<ul><li><a href='/loot?item=legend-spike'>Legend Spike</a></li> 
<ul><li><a href='/loot?item=ghostflame'>Ghostflame</a></li> 
</ul> 
<li><a href='/loot?item=fanged-knife'>Fanged Knife</a></li> 
<ul><li><a href='/loot?item=fleshripper'>Fleshripper</a></li> 
</ul> 
<li><a href='/loot?item=mithral-point'>Mithral Point</a></li> 
<li><a href='/loot?item=bone-knife'>Bone Knife</a></li> 
<ul><li><a href='/loot?item=wizardspike'>Wizardspike</a></li> 
</ul> 
<li><a href='/loot?item=stilleto'>Stilleto</a></li> 
<ul><li><a href='/loot?item=stormspike'>Stormspike</a></li> 
</ul> 
<li><a href='/loot?item=cinquedeas'>Cinquedeas</a></li> 
<ul><li><a href='/loot?item=blackbogs-sharp'>Blackbog's Sharp</a></li> 
</ul> 
<li><a href='/loot?item=rondel'>Rondel</a></li> 
<ul><li><a href='/loot?item=heart-carver'>Heart Carver</a></li> 
</ul> 
<li><a href='/loot?item=poignard'>Poignard</a></li> 
<ul><li><a href='/loot?item=spineripper'>Spineripper</a></li> 
</ul> 
<li><a href='/loot?item=blade'>Blade</a></li> 
<ul><li><a href='/loot?item=irices-shard'>Irices Shard</a></li> 
</ul> 
<li><a href='/loot?item=kris'>Kris</a></li> 
<ul><li><a href='/loot?item=the-jade-tan-do'>The Jade Tan Do</a></li> 
</ul> 
<li><a href='/loot?item=dirk'>Dirk</a></li> 
<ul><li><a href='/loot?item=the-diggler'>The Diggler</a></li> 
</ul> 
<li><a href='/loot?item=dagger'>Dagger</a></li> 
<ul><li><a href='/loot?item=gull'>Gull</a></li> 
</ul> 
<li><a href='/loot?item=gidbinn'>Gidbinn</a></li> 
</ul> 
<li>Mace</li> 
<ul><li><a href='/loot?item=scourge'>Scourge</a></li> 
<ul><li><a href='/loot?item=stormlash'>Stormlash</a></li> 
<li><a href='/loot?item=horizons-tornado'>Horizon's Tornado</a></li> 
</ul> 
<li><a href='/loot?item=devil-star'>Devil Star</a></li> 
<ul><li><a href='/loot?item=baranars-star'>Baranar's Star</a></li> 
</ul> 
<li><a href='/loot?item=reinforced-mace'>Reinforced Mace</a></li> 
<li><a href='/loot?item=knout'>Knout</a></li> 
<ul><li><a href='/loot?item=baezils-vortex'>Baezil's Vortex</a></li> 
</ul> 
<li><a href='/loot?item=jagged-star'>Jagged Star</a></li> 
<ul><li><a href='/loot?item=moonfall'>Moonfall</a></li> 
</ul> 
<li><a href='/loot?item=flanged-mace'>Flanged Mace</a></li> 
<ul><li><a href='/loot?item=sureshrill-frost'>Sureshrill Frost</a></li> 
</ul> 
<li><a href='/loot?item=flail'>Flail</a></li> 
<ul><li><a href='/loot?item=the-generals-tan-do-li-ga'>The Generals Tan Do Li Ga</a></li> 
<li><a href='/loot?item=khalimflail'>KhalimFlail</a></li> 
<li><a href='/loot?item=superkhalimflail'>SuperKhalimFlail</a></li> 
</ul> 
<li><a href='/loot?item=morning-star'>Morning Star</a></li> 
<ul><li><a href='/loot?item=bloodrise'>Bloodrise</a></li> 
</ul> 
<li><a href='/loot?item=mace'>Mace</a></li> 
<ul><li><a href='/loot?item=crushflange'>Crushflange</a></li> 
</ul> 
<li><a href='/loot?item=khalimflail'>KhalimFlail</a></li> 
<li><a href='/loot?item=superkhalimflail'>SuperKhalimFlail</a></li> 
</ul> 
<li>Polearm</li> 
<ul><li><a href='/loot?item=giant-thresher'>Giant Thresher</a></li> 
<ul><li><a href='/loot?item=stormspire'>Stormspire</a></li> 
</ul> 
<li><a href='/loot?item=great-poleaxe'>Great PoleAxe</a></li> 
<li><a href='/loot?item=cryptic-axe'>Cryptic Axe</a></li> 
<ul><li><a href='/loot?item=tomb-reaver'>Tomb Reaver</a></li> 
</ul> 
<li><a href='/loot?item=thresher'>Thresher</a></li> 
<ul><li><a href='/loot?item=the-reapers-toll'>The Reaper's Toll</a></li> 
</ul> 
<li><a href='/loot?item=colossus-voulge'>Colossus Voulge</a></li> 
<li><a href='/loot?item=ogre-axe'>Ogre Axe</a></li> 
<ul><li><a href='/loot?item=bonehew'>Bonehew</a></li> 
</ul> 
<li><a href='/loot?item=grim-scythe'>Grim Scythe</a></li> 
<ul><li><a href='/loot?item=grims-burning-dead'>Grim's Burning Dead</a></li> 
</ul> 
<li><a href='/loot?item=bec-de-corbin'>Bec-de-Corbin</a></li> 
<ul><li><a href='/loot?item=husoldal-evo'>Husoldal Evo</a></li> 
</ul> 
<li><a href='/loot?item=battle-scythe'>Battle Scythe</a></li> 
<ul><li><a href='/loot?item=athenas-wrath'>Athena's Wrath</a></li> 
</ul> 
<li><a href='/loot?item=bill'>Bill</a></li> 
<ul><li><a href='/loot?item=blackleach-blade'>Blackleach Blade</a></li> 
</ul> 
<li><a href='/loot?item=partizan'>Partizan</a></li> 
<ul><li><a href='/loot?item=pierre-tombale-couant'>Pierre Tombale Couant</a></li> 
</ul> 
<li><a href='/loot?item=war-scythe'>War Scythe</a></li> 
<ul><li><a href='/loot?item=the-grim-reaper'>The Grim Reaper</a></li> 
</ul> 
<li><a href='/loot?item=lochaber-axe'>Lochaber Axe</a></li> 
<ul><li><a href='/loot?item=the-meat-scraper'>The Meat Scraper</a></li> 
</ul> 
<li><a href='/loot?item=halberd'>Halberd</a></li> 
<ul><li><a href='/loot?item=woestave'>Woestave</a></li> 
</ul> 
<li><a href='/loot?item=poleaxe'>PoleAxe</a></li> 
<ul><li><a href='/loot?item=the-battlebranch'>The Battlebranch</a></li> 
</ul> 
<li><a href='/loot?item=scythe'>Scythe</a></li> 
<ul><li><a href='/loot?item=soul-harvest'>Soul Harvest</a></li> 
</ul> 
<li><a href='/loot?item=voulge'>Voulge</a></li> 
<ul><li><a href='/loot?item=steelgoad'>Steelgoad</a></li> 
</ul> 
<li><a href='/loot?item=bardiche'>Bardiche</a></li> 
<ul><li><a href='/loot?item=dimoaks-hew'>Dimoaks Hew</a></li> 
</ul> 
</ul> 
<li>Scepter</li> 
<ul><li><a href='/loot?item=caduceus'>Caduceus</a></li> 
<ul><li><a href='/loot?item=ironward'>Ironward</a></li> 
</ul> 
<li><a href='/loot?item=seraph-rod'>Seraph Rod</a></li> 
<li><a href='/loot?item=mighty-scepter'>Mighty Scepter</a></li> 
<ul><li><a href='/loot?item=the-reedeemer'>The Reedeemer</a></li> 
<li><a href='/loot?item=heavens-light'>Heaven's Light</a></li> 
</ul> 
<li><a href='/loot?item=divine-scepter'>Divine Scepter</a></li> 
<ul><li><a href='/loot?item=hand-of-blessed-light'>Hand Of Blessed Light</a></li> 
</ul> 
<li><a href='/loot?item=holy-water-sprinkler'>Holy Water Sprinkler</a></li> 
<ul><li><a href='/loot?item=the-fetid-sprinkler'>The Fetid Sprinkler</a></li> 
</ul> 
<li><a href='/loot?item=rune-scepter'>Rune Scepter</a></li> 
<ul><li><a href='/loot?item=zakarums-hand'>Zakarum's Hand</a></li> 
</ul> 
<li><a href='/loot?item=war-scepter'>War Scepter</a></li> 
<ul><li><a href='/loot?item=stormeye'>Stormeye</a></li> 
</ul> 
<li><a href='/loot?item=grand-scepter'>Grand Scepter</a></li> 
<ul><li><a href='/loot?item=rusthandle'>Rusthandle</a></li> 
</ul> 
<li><a href='/loot?item=scepter'>Scepter</a></li> 
<ul><li><a href='/loot?item=knell-striker'>Knell Striker</a></li> 
</ul> 
</ul> 
<li>Sorceress Orb</li> 
<ul><li><a href='/loot?item=dimensional-shard'>Dimensional Shard</a></li> 
<ul><li><a href='/loot?item=fathom'>Fathom</a></li> 
</ul> 
<li><a href='/loot?item=vortex-orb'>Vortex Orb</a></li> 
<li><a href='/loot?item=demon-heart'>Demon Heart</a></li> 
<li><a href='/loot?item=eldritch-orb'>Eldritch Orb</a></li> 
<ul><li><a href='/loot?item=eschutas-temper'>Eschuta's Temper</a></li> 
</ul> 
<li><a href='/loot?item=heavenly-stone'>Heavenly Stone</a></li> 
<li><a href='/loot?item=swirling-crystal'>Swirling Crystal</a></li> 
<ul><li><a href='/loot?item=the-oculus'>The Oculus</a></li> 
</ul> 
<li><a href='/loot?item=sparkling-ball'>Sparkling Ball</a></li> 
<li><a href='/loot?item=cloudy-sphere'>Cloudy Sphere</a></li> 
<li><a href='/loot?item=crystalline-globe'>Crystalline Globe</a></li> 
<li><a href='/loot?item=glowing-orb'>Glowing Orb</a></li> 
<li><a href='/loot?item=dragon-stone'>Dragon Stone</a></li> 
<li><a href='/loot?item=clamazon-speard-orb'>ClAmazon Speard Orb</a></li> 
<li><a href='/loot?item=smoked-sphere'>Smoked Sphere</a></li> 
<li><a href='/loot?item=sacred-globe'>Sacred Globe</a></li> 
<li><a href='/loot?item=eagle-orb'>Eagle Orb</a></li> 
</ul> 
<li>Spear</li> 
<ul><li><a href='/loot?item=war-pike'>War Pike</a></li> 
<ul><li><a href='/loot?item=steelpillar'>Steelpillar</a></li> 
</ul> 
<li><a href='/loot?item=ghost-spear'>Ghost Spear</a></li> 
<li><a href='/loot?item=mancatcher'>Mancatcher</a></li> 
<li><a href='/loot?item=stygian-pike'>Stygian Pike</a></li> 
<li><a href='/loot?item=hyperion-spear'>Hyperion Spear</a></li> 
<ul><li><a href='/loot?item=ariocs-needle'>Arioc's Needle</a></li> 
</ul> 
<li><a href='/loot?item=lance'>Lance</a></li> 
<ul><li><a href='/loot?item=spire-of-honor'>Spire Of Honor</a></li> 
</ul> 
<li><a href='/loot?item=yari'>Yari</a></li> 
<ul><li><a href='/loot?item=hone-sundan'>Hone Sundan</a></li> 
</ul> 
<li><a href='/loot?item=war-fork'>War Fork</a></li> 
<ul><li><a href='/loot?item=viperfork'>Viperfork</a></li> 
<li><a href='/loot?item=soulfeast-tine'>Soulfeast Tine</a></li> 
</ul> 
<li><a href='/loot?item=fuscina'>Fuscina</a></li> 
<ul><li><a href='/loot?item=kelpie-snare'>Kelpie Snare</a></li> 
</ul> 
<li><a href='/loot?item=war-spear'>War Spear</a></li> 
<ul><li><a href='/loot?item=the-impaler'>The Impaler</a></li> 
</ul> 
<li><a href='/loot?item=pike'>Pike</a></li> 
<ul><li><a href='/loot?item=the-tannr-gorerod'>The Tannr Gorerod</a></li> 
</ul> 
<li><a href='/loot?item=spetum'>Spetum</a></li> 
<ul><li><a href='/loot?item=lance-of-yaggai'>Lance Of Yaggai</a></li> 
</ul> 
<li><a href='/loot?item=brandistock'>Brandistock</a></li> 
<ul><li><a href='/loot?item=bloodthief'>Bloodthief</a></li> 
</ul> 
<li><a href='/loot?item=trident'>Trident</a></li> 
<ul><li><a href='/loot?item=razortine'>Razortine</a></li> 
</ul> 
<li><a href='/loot?item=spear'>Spear</a></li> 
<ul><li><a href='/loot?item=the-dragon-chang'>The Dragon Chang</a></li> 
</ul> 
</ul> 
<li>Staff</li> 
<ul><li><a href='/loot?item=archon-staff'>Archon Staff</a></li> 
<ul><li><a href='/loot?item=mang-songs-lesson'>Mang Song's Lesson</a></li> 
</ul> 
<li><a href='/loot?item=shillelah'>Shillelah</a></li> 
<li><a href='/loot?item=elder-staff'>Elder Staff</a></li> 
<ul><li><a href='/loot?item=ondals-wisdom'>Ondal's Wisdom</a></li> 
</ul> 
<li><a href='/loot?item=stalagmite'>Stalagmite</a></li> 
<li><a href='/loot?item=walking-stick'>Walking Stick</a></li> 
<li><a href='/loot?item=rune-staff'>Rune Staff</a></li> 
<ul><li><a href='/loot?item=skullcollector'>Skullcollector</a></li> 
</ul> 
<li><a href='/loot?item=gothic-staff'>Gothic Staff</a></li> 
<ul><li><a href='/loot?item=warpspear'>Warpspear</a></li> 
</ul> 
<li><a href='/loot?item=cedar-staff'>Cedar Staff</a></li> 
<ul><li><a href='/loot?item=chromatic-ire'>Chromatic Ire</a></li> 
</ul> 
<li><a href='/loot?item=quarterstaff'>Quarterstaff</a></li> 
<ul><li><a href='/loot?item=ribcracker'>Ribcracker</a></li> 
</ul> 
<li><a href='/loot?item=jo-staff'>Jo Staff</a></li> 
<ul><li><a href='/loot?item=razorswitch'>Razorswitch</a></li> 
</ul> 
<li><a href='/loot?item=war-staff'>War Staff</a></li> 
<ul><li><a href='/loot?item=the-iron-jang-bong'>The Iron Jang Bong</a></li> 
</ul> 
<li><a href='/loot?item=battle-staff'>Battle Staff</a></li> 
<ul><li><a href='/loot?item=the-salamander'>The Salamander</a></li> 
</ul> 
<li><a href='/loot?item=gnarled-staff'>Gnarled Staff</a></li> 
<ul><li><a href='/loot?item=lazarus-spire'>Lazarus Spire</a></li> 
</ul> 
<li><a href='/loot?item=long-staff'>Long Staff</a></li> 
<ul><li><a href='/loot?item=serpent-lord'>Serpent Lord</a></li> 
</ul> 
<li><a href='/loot?item=short-staff'>Short Staff</a></li> 
<ul><li><a href='/loot?item=bane-ash'>Bane Ash</a></li> 
</ul> 
<li><a href='/loot?item=horadric-staff'>Horadric Staff</a></li> 
</ul> 
<li>Sword</li> 
<ul><li><a href='/loot?item=colossus-blade'>Colossus Blade</a></li> 
<ul><li><a href='/loot?item=the-grandfather'>The Grandfather</a></li> 
</ul> 
<li><a href='/loot?item=mythical-sword'>Mythical Sword</a></li> 
<li><a href='/loot?item=cryptic-sword'>Cryptic Sword</a></li> 
<ul><li><a href='/loot?item=frostwind'>Frostwind</a></li> 
</ul> 
<li><a href='/loot?item=colossal-sword'>Colossal Sword</a></li> 
<li><a href='/loot?item=conquest-sword'>Conquest Sword</a></li> 
<li><a href='/loot?item=champion-sword'>Champion Sword</a></li> 
<ul><li><a href='/loot?item=doombringer'>Doombringer</a></li> 
</ul> 
<li><a href='/loot?item=phase-blade'>Phase Blade</a></li> 
<ul><li><a href='/loot?item=azurewrath'>Azurewrath</a></li> 
<li><a href='/loot?item=lightsabre'>Lightsabre</a></li> 
</ul> 
<li><a href='/loot?item=balrog-blade'>Balrog Blade</a></li> 
<ul><li><a href='/loot?item=flamebellow'>Flamebellow</a></li> 
</ul> 
<li><a href='/loot?item=hydra-edge'>Hydra Edge</a></li> 
<li><a href='/loot?item=highland-blade'>Highland Blade</a></li> 
<li><a href='/loot?item=elegant-blade'>Elegant Blade</a></li> 
<ul><li><a href='/loot?item=bloodmoon'>Bloodmoon</a></li> 
</ul> 
<li><a href='/loot?item=ataghan'>Ataghan</a></li> 
<ul><li><a href='/loot?item=djinnslayer'>Djinnslayer</a></li> 
</ul> 
<li><a href='/loot?item=legend-sword'>Legend Sword</a></li> 
<li><a href='/loot?item=falcata'>Falcata</a></li> 
<li><a href='/loot?item=executioner-sword'>Executioner Sword</a></li> 
<ul><li><a href='/loot?item=swordguard'>Swordguard</a></li> 
</ul> 
<li><a href='/loot?item=zweihander'>Zweihander</a></li> 
<ul><li><a href='/loot?item=todesfaelle-flamme'>Todesfaelle Flamme</a></li> 
</ul> 
<li><a href='/loot?item=ancient-sword'>Ancient Sword</a></li> 
<ul><li><a href='/loot?item=the-atlantian'>The Atlantian</a></li> 
</ul> 
<li><a href='/loot?item=gothic-sword'>Gothic Sword</a></li> 
<ul><li><a href='/loot?item=cloudcrack'>Cloudcrack</a></li> 
</ul> 
<li><a href='/loot?item=tusk-sword'>Tusk Sword</a></li> 
<ul><li><a href='/loot?item=the-vile-husk'>The Vile Husk</a></li> 
</ul> 
<li><a href='/loot?item=rune-sword'>Rune Sword</a></li> 
<ul><li><a href='/loot?item=plague-bearer'>Plague Bearer</a></li> 
</ul> 
<li><a href='/loot?item=cutlass'>Cutlass</a></li> 
<ul><li><a href='/loot?item=coldsteel-eye'>Coldsteel Eye</a></li> 
</ul> 
<li><a href='/loot?item=dacian-falx'>Dacian Falx</a></li> 
<ul><li><a href='/loot?item=bing-sz-wang'>Bing Sz Wang</a></li> 
</ul> 
<li><a href='/loot?item=battle-sword'>Battle Sword</a></li> 
<ul><li><a href='/loot?item=headstriker'>Headstriker</a></li> 
</ul> 
<li><a href='/loot?item=tulwar'>Tulwar</a></li> 
<ul><li><a href='/loot?item=blade-of-ali-baba'>Blade Of Ali Baba</a></li> 
</ul> 
<li><a href='/loot?item=espadon'>Espadon</a></li> 
<ul><li><a href='/loot?item=crainte-vomir'>Crainte Vomir</a></li> 
</ul> 
<li><a href='/loot?item=dimensional-blade'>Dimensional Blade</a></li> 
<ul><li><a href='/loot?item=ginthers-rift'>Ginther's Rift</a></li> 
</ul> 
<li><a href='/loot?item=shamshir'>Shamshir</a></li> 
<ul><li><a href='/loot?item=hexfire'>Hexfire</a></li> 
</ul> 
<li><a href='/loot?item=great-sword'>Great Sword</a></li> 
<ul><li><a href='/loot?item=the-patriarch'>The Patriarch</a></li> 
</ul> 
<li><a href='/loot?item=gladius'>Gladius</a></li> 
<ul><li><a href='/loot?item=bloodletter'>Bloodletter</a></li> 
</ul> 
<li><a href='/loot?item=flamberge'>Flamberge</a></li> 
<ul><li><a href='/loot?item=ripsaw'>Ripsaw</a></li> 
</ul> 
<li><a href='/loot?item=war-sword'>War Sword</a></li> 
<ul><li><a href='/loot?item=culwens-point'>Culwens Point</a></li> 
</ul> 
<li><a href='/loot?item=bastard-sword'>Bastard Sword</a></li> 
<ul><li><a href='/loot?item=blacktongue'>Blacktongue</a></li> 
</ul> 
<li><a href='/loot?item=giant-sword'>Giant Sword</a></li> 
<ul><li><a href='/loot?item=kinemils-awl'>Kinemils Awl</a></li> 
</ul> 
<li><a href='/loot?item=long-sword-'>Long Sword </a></li> 
<ul><li><a href='/loot?item=hellplague'>Hellplague</a></li> 
</ul> 
<li><a href='/loot?item=claymore'>Claymore</a></li> 
<ul><li><a href='/loot?item=soulflay'>Soulflay</a></li> 
</ul> 
<li><a href='/loot?item=broad-sword'>Broad Sword</a></li> 
<ul><li><a href='/loot?item=griswolds-edge'>Griswolds Edge</a></li> 
</ul> 
<li><a href='/loot?item=crystal-sword'>Crystal Sword</a></li> 
<li><a href='/loot?item=falchion'>Falchion</a></li> 
<ul><li><a href='/loot?item=gleamscythe'>Gleamscythe</a></li> 
</ul> 
<li><a href='/loot?item=two-handed-sword'>Two-Handed Sword</a></li> 
<ul><li><a href='/loot?item=shadowfang'>Shadowfang</a></li> 
</ul> 
<li><a href='/loot?item=saber'>Saber</a></li> 
<ul><li><a href='/loot?item=krintizs-skewer'>Krintizs Skewer</a></li> 
</ul> 
<li><a href='/loot?item=scimitar'>Scimitar</a></li> 
<ul><li><a href='/loot?item=blood-crescent'>Blood Crescent</a></li> 
</ul> 
<li><a href='/loot?item=short-sword'>Short Sword</a></li> 
<ul><li><a href='/loot?item=rixots-keen'>Rixots Keen</a></li> 
</ul> 
</ul> 
<li>Throwing Axe</li> 
<ul><li><a href='/loot?item=winged-axe'>Winged Axe</a></li> 
<ul><li><a href='/loot?item=lacerator'>Lacerator</a></li> 
</ul> 
<li><a href='/loot?item=flying-axe'>Flying Axe</a></li> 
<ul><li><a href='/loot?item=gimmershred'>Gimmershred</a></li> 
</ul> 
<li><a href='/loot?item=hurlbat'>Hurlbat</a></li> 
<li><a href='/loot?item=francisca'>Francisca</a></li> 
<ul><li><a href='/loot?item=the-scalper'>The Scalper</a></li> 
</ul> 
<li><a href='/loot?item=balanced-axe'>Balanced Axe</a></li> 
<li><a href='/loot?item=throwing-axe'>Throwing Axe</a></li> 
</ul> 
<li>Throwing Knife</li> 
<ul><li><a href='/loot?item=winged-knife'>Winged Knife</a></li> 
<ul><li><a href='/loot?item=warshrike'>Warshrike</a></li> 
</ul> 
<li><a href='/loot?item=flying-knife'>Flying Knife</a></li> 
<li><a href='/loot?item=war-dart'>War Dart</a></li> 
<li><a href='/loot?item=battle-dart'>Battle Dart</a></li> 
<ul><li><a href='/loot?item=deathbit'>Deathbit</a></li> 
</ul> 
<li><a href='/loot?item=balanced-knife'>Balanced Knife</a></li> 
<li><a href='/loot?item=throwing-knife'>Throwing Knife</a></li> 
</ul> 
<li>Throwing Potion</li> 
<ul><li><a href='/loot?item=rancid-gas-potion'>Rancid Gas Potion</a></li> 
<li><a href='/loot?item=oil-potion'>Oil Potion</a></li> 
<li><a href='/loot?item=choking-gas-potion'>Choking Gas Potion</a></li> 
<li><a href='/loot?item=exploding-potion'>Exploding Potion</a></li> 
<li><a href='/loot?item=strangling-gas-potion'>Strangling Gas Potion</a></li> 
<li><a href='/loot?item=fulminating-potion'>Fulminating Potion</a></li> 
</ul> 
<li>Wand</li> 
<ul><li><a href='/loot?item=unearthed-wand'>Unearthed Wand</a></li> 
<ul><li><a href='/loot?item=deathss-web'>Deaths's Web</a></li> 
</ul> 
<li><a href='/loot?item=lich-wand'>Lich Wand</a></li> 
<ul><li><a href='/loot?item=boneshade'>Boneshade</a></li> 
</ul> 
<li><a href='/loot?item=ghost-wand'>Ghost Wand</a></li> 
<li><a href='/loot?item=polished-wand'>Polished Wand</a></li> 
<li><a href='/loot?item=grave-wand'>Grave Wand</a></li> 
<ul><li><a href='/loot?item=blackhand-key'>Blackhand Key</a></li> 
</ul> 
<li><a href='/loot?item=tomb-wand'>Tomb Wand</a></li> 
<ul><li><a href='/loot?item=arm-of-king-leoric'>Arm Of King Leoric</a></li> 
</ul> 
<li><a href='/loot?item=petrified-wand'>Petrified Wand</a></li> 
<ul><li><a href='/loot?item=carin-shard'>Carin Shard</a></li> 
</ul> 
<li><a href='/loot?item=burnt-wand'>Burnt Wand</a></li> 
<ul><li><a href='/loot?item=suicide-branch'>Suicide Branch</a></li> 
</ul> 
<li><a href='/loot?item=grim-wand'>Grim Wand</a></li> 
<ul><li><a href='/loot?item=umes-lament'>Umes Lament</a></li> 
</ul> 
<li><a href='/loot?item=bone-wand'>Bone Wand</a></li> 
<ul><li><a href='/loot?item=gravenspine'>Gravenspine</a></li> 
</ul> 
<li><a href='/loot?item=yew-wand'>Yew Wand</a></li> 
<ul><li><a href='/loot?item=maelstromwrath'>Maelstromwrath</a></li> 
</ul> 
<li><a href='/loot?item=wand'>Wand</a></li> 
<ul><li><a href='/loot?item=iros-torch'>Iros Torch</a></li> 
</ul> 
</ul> 
</ul> 
</ul> 
</div>
<?php include(F3::get('GUI') . "/includes/footer.php") ?> 