            </div>
            <div class="module mod-footer">
                <img title="PHP" class="logo" src="/img/phplogo.png">
                <img title="MySQL" class="logo" src="/img/mysqllogo.png">
                <img title="F3 Fat Free Framework" class="logo" src="/img/f3logo.png">
            </div>
        </div>
        <script src="jscript/jquery.js"></script>
        <script src="jscript/leviatha.js"></script>
    </body>
</html>
