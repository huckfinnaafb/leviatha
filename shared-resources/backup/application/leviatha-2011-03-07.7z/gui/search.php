<?php include(F3::get('GUI') . "/includes/header.php") ?>
<div class="module mod-tip">
    <p>Browse the library of items using the <a href="/loot" class="link">Master Loot Directory</a>.</p>
</div>

<div class="module mod-search">
    <table class="table-search">
        <thead class="thead-search">
            <tr>
                <th class="theading-search"></th>
                <th class="theading-search">Name</th>
                <th class="theading-search">Parent</th>
                <th class="theading-search">Level Req.</th>
                <th class="theading-search">Item Level</th>
            </tr>
        </thead>
        <tbody class="tbody-search"><?php
            foreach ($this->db_result as $row) {
                
                switch ($row["rarity"]) {
                    case("normal"): $color = "none"; break;
                    case("unique"): $color = "#f9f7e4"; break;
                    case("set"): $color = "#e7f9e4"; break;
                    case("runeword"): $color = "#f9ebe4"; break;
                }
                
                echo ("
                <tr>
                    <td style='background-color:{$color}'><img class='lena-tiny' src='/img/lena128.png'></td>
                    <td><a href='loot?item={$row['urlname']}'>{$row['name']}</a></td>
                    <td>". ucwords($row['parent']) ."</td>
                    <td>{$row['levelreq']}</td>
                    <td>{$row['level']}</td>
                </tr>");
            }
            ?>

        </tbody>
    </table>
</div>

<?php include(F3::get('GUI') . "/includes/footer.php") ?>
