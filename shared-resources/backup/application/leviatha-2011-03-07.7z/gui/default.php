<!DOCTYPE html>
<html>
    <head>
        <title>Leviatha - Diablo Database | Loot, Monsters, and More!</title>
        <meta name="keywords" content="diablo database, diablo 2 database">
        <meta name="description" content="A pretty horrible Diablo database. Browse at own risk.">
        <meta name="robots" content="all">
        <meta name="language" content="English">
        <meta name="author" content="Samuel FerrelL">
        <meta name="copyright" content="Copyright 2011 - Samuel Ferrell">
        <link rel="stylesheet" href="/css/reset.css" />
        <link rel="stylesheet" href="/css/style.css" />
        <style>
            .page {
                text-align: center; 
                width: 960px; 
                margin: auto;
                margin-top: 60px; 
            }
            .h-title {
                font-size: 140px;
                letter-spacing: 15px;
                line-height: .8em;
            } 
            nav {
                margin-top: 16px; 
                margin-bottom: 16px; 
            }
            header { border: 0 }
        </style>
        <script type="text/javascript">
            var _gaq = _gaq || [];
            _gaq.push(['_setAccount', 'UA-21869873-1']);
            _gaq.push(['_trackPageview']);

            (function() {
            var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
            ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
            var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
            })();
        </script>
    </head>
    <body>
        <div class="page">
            <header class="module mod-header">
                <hgroup>
                    <h1 class="heading h-title">Leviatha</h1>
                </hgroup>
                <nav>
                    <a class="link link-nav" href="/">Home</a>
                    <a class="link link-nav" href="/loot">Loot</a>
                    <a class="link-nav" href="/blog">Development Blog</a>
                </nav>
                <form action="search" method="get" class="form form-search">
                    <fieldset class="fieldset field-search">
                        <input type="text" class="input input-text" name="q" selected="selected"/>
                        <input type="submit" class="input input-submit" value="Search"/>
                    </fieldset>
                </form>
            </header>
            <footer class="module mod-footer">
                <p class="beta">Leviatha is a live project and is subject to completely screwing up for no reason.</p>
                <p class="text text-copyright">Powered by <a href="http://fatfree.sourceforge.net/">F3 Fat Free</a>.</p>
            </footer>
        </div>
        <script src="/jscript/jquery.js"></script>
        <script src="/jscript/leviatha.js"></script>
    </body>
</html> 
