<div class="module">
    <h1 class="h-mod">Normal properties</h1>
    <table>
        <tbody>
            <?php
                /* Normal Properties Loop */
                foreach($this->db_item["prop_normal"] as $row) {
                    echo "<tr>";
                        echo "<td>{$row['property']}</td>";
                        echo "<td>{$row['value']}</td>";
                    echo "</tr>";
                }
            ?>
        </tbody>
    </table>
</div>
