<div class="module">
    <h1 class="h-mod">Magic properties</h1>
    <table>
        <tbody>
            <?php
                foreach($this->db_item["prop_magic"] as $row) {
                    echo "<tr class='magic'>";
                        echo "<td>{$row['property']}</td>";
                        if (isset($row["param"])) 
                            echo "<td>{$row['param']}</td>";
                        else
                            echo "<td>NULL</td>";
                        if (isset($row["min"])) echo "<td>{$row['min']}</td>";
                        if (isset($row["max"])) echo "<td>{$row['max']}</td>";
                    echo "</tr>\n";
                }
            ?>
        </tbody>
    </table>
</div>
