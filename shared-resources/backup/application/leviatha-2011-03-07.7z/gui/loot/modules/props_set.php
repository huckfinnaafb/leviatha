<div class="module">
    <h1 class="h-mod">Set Bonuses</h1>
    <table>
        <tbody>
            <?php
                foreach($this->db_item["prop_set"] as $row) {
                    echo "<tr class='set'>";
                        echo "<td>{$row['property']}</td>";
                        if (isset($row["param"])) 
                            echo "<td>{$row['param']}</td>";
                        else
                            echo "<td></td>";
                        if (isset($row["min"])) echo "<td>{$row['min']}</td>";
                        if (isset($row["max"])) echo "<td>{$row['max']}</td>";
                        if (isset($row["max"])) echo "<td>( {$row['req_equip']} Equipped )</td>";
                    echo "</tr>";
                }
            ?>
        </tbody>
    </table>
</div>
