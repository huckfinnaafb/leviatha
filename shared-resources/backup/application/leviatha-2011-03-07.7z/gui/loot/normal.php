<!-- Header -->
<?php include(F3::get('GUI') . "/includes/header.php") ?>

<!-- Common Properties -->
<div class="module">
    <img class='lena-big' src="/img/lena128.png" style="float: left; margin: 0 10px 10px 0;">
    <h1 class="h-page"><?php echo $this->db_item["common"]["name"] ?></h1>
    <p class="text-info">Level <?php echo $this->db_item["common"]["level"] . " " . ucwords($this->db_item["common"]["division"]) ?></p>
    <p class="text-info">Required Level: <?php echo $this->db_item["common"]["levelreq"]; ?></p>
</div>

<!-- Normal Properties -->
<?php include(F3::get('GUI') . "loot/modules/props_normal.php") ?>

<!-- Magic Variants -->
<?php include(F3::get('GUI') . "loot/modules/variants.php") ?>

<!-- Footer -->
<?php include(F3::get('GUI') . "/includes/footer.php") ?>
