<?php include(F3::get('GUI') . "/includes/header.php") ?>
<div class="module">
    <h1 class="heading h-page">Master Loot Directory</h1>
</div>
<div class="module mod-tip">
    <p>Expand each section to see common items and their magical equivalents, ordered by group alphabetically and then in ascending order by level.</p>
</div>
<div class="module">
    <ul class="list-directory">
        <?php
            $query_kingdom = "
                SELECT kingdom, domain
                FROM relate_kingdom
                WHERE domain = 'loot'
            ";
            F3::sql($query_kingdom);
            foreach(F3::get('DB.result') as $kingdom) {
                echo "<li>" . ucwords($kingdom["kingdom"]) . "</li>\n";
                echo "<ul>";
                $kingdom = $kingdom["kingdom"];
                $query_division = "
                    SELECT division
                    FROM relate_division
                    WHERE kingdom = '$kingdom'
                ";
                F3::sql($query_division);
                foreach(F3::get('DB.result') as $division) {
                    echo "<li>" . ucwords($division["division"]) . "</li>\n";
                    echo "<ul>";
                    $division = $division["division"];
                    $query_class = "
                        SELECT name, urlname
                        FROM loot
                        WHERE division = '$division'
                    ";
                    F3::sql($query_class);
                    foreach(F3::get('DB.result') as $class) {
                        echo "<li><a href='/loot?item={$class['urlname']}'>" . ucwords($class["name"]) . "</a></li>\n";
                        echo "<ul>";
                        $class = $class["name"];
                        $query_magic = "
                            SELECT name, urlname
                            FROM loot_magic
                            WHERE class = '$class'
                        ";
                        F3::sql($query_magic);
                        foreach(F3::get('DB.result') as $magic) {
                            echo "<li><a href='/loot?item={$magic['urlname']}'>" . ucwords($magic["name"]) . "</a></li>\n";
                        }
                        echo "</ul>\n";
                    }
                    echo "</ul>\n";
                }
                echo "</ul>\n";
            }
        ?>
    </ul>
</div>
<?php include(F3::get('GUI') . "/includes/footer.php") ?>
