<?php
define ('__SITE_PATH', realpath(dirname(__DIR__)));

// PHP Fat Free Framework (http://fatfree.sourceforge.net/)
require_once (__SITE_PATH . "/library/F3/F3/F3.php");

// Framework settings and configurations
F3::set('RELEASE',TRUE);
F3::set('GUI', __SITE_PATH . '/gui/');
F3::set('DB',
    array(
        'dsn'=>'mysql:host=127.0.0.1;port=3306;dbname=leviatha',
        'user'=>'leviathan',
        'password'=>'q34w8AwxcVcass6z'
    )
);
F3::set('AUTOLOAD',
    __SITE_PATH . "/application/|" .
    __SITE_PATH . "/library/F3/autoload/");
F3::set('GET',F3::scrub($_GET));

// Routers
F3::route('GET /', function () { include (F3::get('GUI') . "default.php"); });
F3::route('GET /search', array(new search, 'init'));
F3::route('GET /loot', array(new loot, 'init'));
F3::route('GET /sitemap', function () {F3::sitemap();});

// Execute
F3::run();
