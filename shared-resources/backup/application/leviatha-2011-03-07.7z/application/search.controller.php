<?php
    /*
        Author: Samuel Ferrell
        Purpose: Query Database for Relevant Matches to Global Search Field
        GUI Include(s): /gui/search.php
        
        Todo:   
            Improve search relevancy
            Suggestions on search fail
                Search by division
                Search by kingdom
                Return google matches
    */
    class search {
        public $input_raw;
        public $input_clean;
        
        /* Database Results & Properties */
        public $db_limit = 30;
        public $db_offset = 0;
        public $db_result;
        
        public function init() {
            
            /* Check if query is set */
            if (!isset($_GET["q"])) {
                throw new Exception("Query variable not set");
            } else {
                $this->input_raw = $_GET["q"];
            }
            
            /* Scrub user input. Assign result to input_clean */
            $this->input_clean = F3::scrub($this->input_raw);
            
            /* Check against integers in input */
            if (strcspn($this->input_clean, '0123456789') != strlen($this->input_clean)) {
                throw new Exception("Query cannot include integers.");
            }
            
            /* Check if query is empty */
            if (!strlen($this->input_clean)) {
                throw new Exception("Query is empty");
            }
            
            /* Prepare query for DB use */
            $this->input_clean = $this->url_prep($this->input_clean);
            
            /* Query Loot */
            $this->db_result = $this->search_loot();
            
            /* Include Search Template */
            if (count($this->db_result)) {
                include (F3::get('GUI') . "search.php");
            } else {
                throw new Exception("Nothing found.");
            }
        }
        
        public function url_prep($string) {
            $string = htmlspecialchars($string);        /* Strip html chars */
            $string = mysql_escape_string($string);     /* Escape mysql chars */
            $string = str_replace(' ', '-', $string);   /* Replace whitespace with dashes */
            $string = str_replace("'", '', $string);    /* Remove single quotes */
            
            return $string;
        }
        
        public function search_loot() {
            $query = "
                (SELECT name, urlname, level, division AS parent, levelreq, rarity
                FROM loot
                WHERE urlname
                LIKE '%$this->input_clean%')
                UNION
                (SELECT name, urlname, level, class AS parent, levelreq, rarity
                FROM loot_magic
                WHERE urlname
                LIKE '%$this->input_clean%')
                ORDER BY level DESC
            ";
            return F3::sql($query);
        }
    }