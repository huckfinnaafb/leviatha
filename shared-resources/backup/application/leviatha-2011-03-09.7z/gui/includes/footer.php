            </div>
            <footer class="module mod-footer">
                <p class="beta">Leviatha is a live project and is subject to completely screwing up for no reason.</p>
                <p class="text text-copyright">Powered by <a href="http://fatfree.sourceforge.net/">F3 Fat Free</a>.</p>
            </footer>
        </div>
        <script src="jscript/jquery.js"></script>
        <script src="jscript/leviatha.js"></script>
    </body>
</html>
