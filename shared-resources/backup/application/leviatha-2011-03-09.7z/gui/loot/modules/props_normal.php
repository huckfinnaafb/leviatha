<div class="module">
    <table>
        <tbody>
            <?php
                try {
                    if (isset($this->db_item["prop_normal"]) && (!empty($this->db_item["prop_normal"]))) {
                        foreach($this->db_item["prop_normal"] as $row) {
                            echo "<tr>";
                                echo "<td>{$row['translation']}</td>";
                                echo "<td>{$row['value']}</td>";
                            echo "</tr>";
                        }
                    } else {
                        throw new Exception("No normal properties found.");
                    }
                } catch (Exception $e) {
                    echo "<p>" . $e->getMessage(), "</p>\n";
                }
            ?>
        </tbody>
    </table>
</div>
