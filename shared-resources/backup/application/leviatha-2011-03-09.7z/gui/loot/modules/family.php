<div class="module">
    <h1 class="h-mod">The <strong><?php echo $this->db_family["family"] ?></strong> Family</h1>
    <ul>
        <?php
            foreach($this->db_family["members"] as $row) {
                echo "<li><a href='/loot?item={$row["urlname"]}'>{$row["name"]}</a></li>";
            }
        ?>
    </ul>
</div>
