<div class="module">
    <table>
        <tbody>
            <?php
                try {
                    if (isset($this->db_item["prop_magic"]) && (!empty($this->db_item["prop_magic"]))) {
                        foreach($this->db_item["prop_magic"] as $row) {
                            echo "<tr class='magic'>";
                                
                                echo "<td>{$row['property']}</td>";
                                
                                if (isset($row["param"])) {
                                    echo "<td>{$row['param']}</td>";
                                } else { 
                                    echo "<td></td>"; 
                                }
                                
                                if (isset($row["min"]) && (isset($row["max"]))) {
                                    if ($row["min"] == $row["max"]) {
                                        echo "<td colspan='2'>{$row["min"]}</td>";
                                    } else {
                                        echo "<td>{$row["min"]}</td><td>{$row["max"]}</td>";
                                    }
                                } else {
                                    echo "<td></td><td></td>";
                                }
                                
                            echo "</tr>\n";
                        }
                    } else {
                        throw new Exception("No magic properties found.");
                    }
                }
                catch (Exception $e) {
                    echo "<p>" . $e->getMessage(), "</p>\n";
                }
            ?>
        </tbody>
    </table>
</div>
