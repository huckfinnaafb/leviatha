<?php
    class script {
        public function init() {
            $query = "
                SELECT *
                FROM raw_loot_properties
            ";
            F3::sql($query);
            $result = F3::get('DB.result');
            
            
            foreach($result as $row) {
            
                $name = $row["name"];
                
                foreach($row as $k => $v) {
                
                    if ($k == "name") { continue; }
                    if ($v == 0) { continue; }
                    if (!is_numeric($v)) { continue; }
                    
                    echo $name . "\t" . strtolower($k) . "\t" . $v . "\n<br>";
                }
            }
        }
        
        public function integrity() {
        
            $query = "
                SELECT loot_properties.property
                FROM loot_properties
                    LEFT JOIN translate_loot_properties
                        ON loot_properties.property = translate_loot_properties.property
                WHERE loot_properties.property IS NULL
            ";
            F3::sql($query);
            
            foreach(F3::get('DB.result') as $k => $v) {
                echo $v["property"] . "<br>";
            }
        }
    }