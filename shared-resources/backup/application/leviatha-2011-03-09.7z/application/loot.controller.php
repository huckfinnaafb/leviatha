<?php
    /*
        Author: Samuel Ferrell
        Purpose: Query and Collate DB Results for Loot
        GUI Include(s): /gui/loot.php, /gui/loot_magic_unique.php
        
        Structure of db_item:
            $db_item = array(
                ["common"] => array(
                    ["name"] => full item name,
                    ["urlname"] => url-friendly item name,
                    ["level"] => item level,
                    ["levelreq"] => level required to equip item,
                    ["rarity"] => rarity of item
                    ["class"] => if magic, the base (parent) item
                    ["classurl"] => url of class
                    ["division"] => category of item
                    ["kingdom"] => group of categories
                    ["domain"] => domain (will always be "loot")
                ),
                ["prop_normal"] => array(
                    [i] => array(
                        ["name"] => item name
                        ["property"] => property name
                        ["value"] => property value
                    )
                ),
                ["prop_magic"] => array(
                    [i] => array(
                        ["name"] => item name
                        ["property"] => property name
                        ["parameter"] => property parameter
                        ["min"] => minimum property value
                        ["max"] => maximum property value
                    )
                ),
                ["prop_set"] => array(
                    [i] => array(
                        ["name"] => item name
                        ["property"] => property name
                        ["parameter"] => property parameter
                        ["min"] => minimum property value
                        ["max"] => maximum property value
                        ["req_equip"] => required number of equipped set to activate bonus
                    )
                ),
                ["flags"] => array(
                    [i] => array(
                        ["name"] => item name
                        ["flag"] => flag name
                        ["value"] => boolean value
                    )
                )
            )
    */
    class loot {
        public $title;
        public $urlname;
        public $range = 10;
        
        /* Database Results */
        public $db_item = array();
        public $db_variants = array();
        public $db_family = array();
        public $db_similar = array();
        
        /* Boolean Properties */
        public $isMagic;
        
        /*
            Function: /loot?item= landing page
            Returns: void
        */
        public function init() {
            
            /* Check if item url is set. If not set, default to loot_directory.php */
            if (!isset($_GET["item"])) {
                $this->title = "Loot Directory";
                include (F3::get('GUI') . "loot/directory.php");
                return false;
            } else {
                $this->urlname = $_GET["item"];
            }
            
            /* Scrub urlname */
            $this->urlname = F3::scrub($this->urlname);
            
            /* Check urlname against integers */
            if (strcspn($this->urlname, '0123456789') != strlen($this->urlname)) {
                throw new Exception("Item name cannot include integers.");
            }
            
            /* Check if query is empty */
            if (!strlen($this->urlname)) {
                throw new Exception("Item String Empty");
            }
            
            /* Collect item info through get_item() and include appropriate template */
            if ($this->db_item = $this->get_item($this->urlname)) {
                $this->title = $this->db_item["common"]["name"];
                if ($this->isMagic) {
                    /* Open Appropriate File Depending on Rarity of Item */
                    switch ($this->db_item["common"]["rarity"]) {
                        case ("unique"): include (F3::get('GUI') . "loot/unique.php"); break;
                        case ("set"): include (F3::get('GUI') . "loot/set.php"); break;
                        case ("runeword"): include (F3::get('GUI') . "loot/runeword.php"); break;
                    }
                } else {
                    /* Base Item File */
                    include (F3::get('GUI') . "loot/normal.php");
                }
            } else {
                throw new Exception("Item data not found.");
            }
        }
        
        /* 
            Function: Quick access to all available loot info
            Returns: array (see class docs), false on failure
        */
        public function get_item($item) {
            
            /* Check whether item exists */
            if (!$this->check_isExists($item)) {
                return false;
            }
            
            /* Check whether item is magic or not */
            $this->isMagic = $this->check_isMagic($item);
            
            /* Property & Flag Collection */
            if ($this->isMagic) {
                $this->db_item["common"] = $this->get_common($item, true);
                $this->db_item["common"]["classurl"] = strtolower(str_replace(" ", "-", str_replace("'", "", $this->db_item["common"]["class"])));
                $this->db_item["prop_normal"] = $this->get_normal(str_replace("'", "\'", $this->db_item["common"]["class"]));
                $this->db_item["prop_magic"] = $this->get_magic(str_replace("'", "\'", $this->db_item["common"]["name"]));
                $this->db_item["flags"] = $this->get_flags(str_replace("'", "\'", $this->db_item["common"]["name"]));
                
                $this->db_similar = $this->get_similar(str_replace("'", "\'", $this->db_item["common"]["name"]), str_replace("'", "\'", $this->db_item["common"]["division"]), $this->db_item["common"]["level"], $this->range);
                
                /* Set Item Bonus Collection */
                if ($this->db_item["common"]["rarity"] == "set") {
                    $this->db_item["prop_set"] = $this->get_set(str_replace("'", "\'", $this->db_item["common"]["name"]));
                    $this->db_family["family"] = $this->get_family(str_replace("'", "\'", $this->db_item["common"]["name"]));
                    $this->db_family["members"] = $this->get_family_members(str_replace("'", "\'", $this->db_family["family"]));
                }
            } else {
                $this->db_item["common"] = $this->get_common($item, false);
                $this->db_item["prop_normal"] = $this->get_normal(str_replace("'", "\'", $this->db_item["common"]["name"]));
                $this->db_item["flags"] = $this->get_flags(str_replace("'", "\'", $this->db_item["common"]["name"]));
                $this->db_variants = $this->get_variants(str_replace("'", "\'", $this->db_item["common"]["name"]));
            }
            
            return $this->db_item;
        }
        
        /* 
            Function: Check if item exists in the database
            Returns: boolean
        */
        public function check_isExists($item) {
            $query = "
                (SELECT urlname FROM loot WHERE urlname = '$item')
                UNION
                (SELECT urlname FROM loot_magic WHERE urlname = '$item')
            ";
            if (F3::sql($query)) {
                return true;
            } else {
                return false;
            }
        }
        
        /* 
            Function: Check if item is magic
            Returns: boolean
        */
        public function check_isMagic($urlname) {
            $query = "SELECT urlname FROM loot_magic WHERE loot_magic.urlname = '$urlname'";
            if (F3::sql($query)) {
                return true;
            } else {
                return false;
            }
        }
        
        /* 
            Function: Get ["common"] properties
            Returns: mysql resource
        */
        public function get_common($urlname, $isMagic = null) {
            
            /* if isMagic is null, attempt to grab class property */
            if (($isMagic === null) && (isset($this->isMagic))) {
                $isMagic = $this->isMagic;
            }
            
            if ($isMagic) {
                $query = "
                    SELECT loot_magic.name, loot_magic.urlname, loot_magic.level, loot_magic.levelreq, loot_magic.class, loot_magic.rarity, loot.division, relate_division.kingdom, relate_kingdom.domain
                    FROM loot
                        JOIN loot_magic 
                            ON loot_magic.class = loot.name
                        JOIN relate_division 
                            ON loot.division = relate_division.division
                        JOIN relate_kingdom 
                            ON relate_division.kingdom = relate_kingdom.kingdom
                        JOIN relate_domain 
                            ON relate_kingdom.domain = relate_domain.domain
                    WHERE loot_magic.urlname = '$urlname'
                ";
                F3::sql($query);
                return F3::get('DB.result.0');
            } else {
                $query = "
                    SELECT loot.name, loot.urlname, loot.level, loot.levelreq, loot.division, relate_division.kingdom, relate_kingdom.domain
                    FROM loot
                        JOIN relate_division 
                            ON loot.division = relate_division.division
                        JOIN relate_kingdom 
                            ON relate_division.kingdom = relate_kingdom.kingdom
                        JOIN relate_domain 
                            ON relate_kingdom.domain = relate_domain.domain
                    WHERE loot.urlname = '$urlname'
                ";
                F3::sql($query);
                return F3::get('DB.result.0');
            }
        }
    
        /* 
            Function: Get ["prop_norm"] properties
            Returns: mysql resource
        */
        public function get_normal($item) {
            $query = "
                SELECT translate_loot_properties.translation, loot_properties.value
                FROM loot_properties 
                JOIN translate_loot_properties
                    ON loot_properties.property = translate_loot_properties.property
                WHERE `name` = '$item'
            ";
            return F3::sql($query);
        }
        
        /* 
            Function: Get ["prop_magic"] properties
            Returns: mysql resource
        */
        public function get_magic($item) {
            $query = "SELECT loot, property, parameter, min, max FROM loot_properties_magic WHERE `loot` = '$item'";
            return F3::sql($query);
        }
        
        /* 
            Function: Get set item family name
            Returns: string
        */
        public function get_family($item) {
            $query = "SELECT `set_family` FROM relate_loot_set WHERE `set_item` = '$item'";
            F3::sql($query);
            return (F3::get('DB.result.0.set_family'));
        }
        
        /*
            Function: Get all members of family
            Returns: mysql resource
        */
        public function get_family_members($family) {
            $query = "
                SELECT loot_magic.name, loot_magic.urlname
                FROM loot_magic
                    JOIN relate_loot_set
                        ON loot_magic.name = relate_loot_set.set_item
                WHERE `set_family` = '$family'";
            return F3::sql($query);
        }
        
        /* 
            Function: Get ["prop_magic_set"] properties
            Returns: mysql resource
        */
        public function get_set($item) {
            $query = "
                SELECT 
                    set_item, 
                    property, 
                    parameter,
                    min,
                    max, 
                    req_equip 
                FROM loot_properties_set 
                WHERE `set_item` = '$item'
                ORDER BY req_equip ASC
            ";
            return F3::sql($query);
        }
        
        /* 
            Function: Get ["flags"] properties
            Returns: mysql resource
        */
        public function get_flags($item) {
            $query = "SELECT loot, flag, value FROM loot_flags WHERE `loot` = '$item'";
            return F3::sql($query);
        }
        
        /*
            Function: Get array of items similar in item level, within range
            Returns: mysql resource
        */
        public function get_similar($item, $division, $level, $range) {
            $min = $level - $range;
            $max = $level + $range;
            $query = "
                SELECT 
                    loot_magic.name, 
                    loot_magic.urlname,
                    loot_magic.level,
                    loot_magic.levelreq,
                    loot.name AS classname
                FROM loot_magic
                    JOIN loot
                        ON loot_magic.class = loot.name
                WHERE (loot_magic.level > '$min') 
                    AND (loot_magic.level < '$max') 
                    NOT IN (loot_magic.name = '$item') 
                    AND (loot.division = '$division')
                ORDER BY loot_magic.level DESC
                LIMIT 5
            ";
            return F3::sql($query);
        }
        
        public function get_variants($item) {
            $query = "
                SELECT name, urlname
                FROM loot_magic
                WHERE `class` = '$item'
            ";
            return F3::sql($query);
        }
    }
