<?php
/**
 * @author huckfinnaafb
 */
class loot extends basecontroller {

	public static function getItem($item = null) {
        
        // If no argument passed, attempt to grab item from _GET
        if ($item == null) {
            $item = $_GET['item'];
        }
        
        // Grab general information about the item from the database
        $shared = self::getShared($item);
        
        // If nothing found, throw error. If found, continue analysis of item
        if (!empty($shared)) {
            
            // Normal Item
            if ($shared[0]["rarity"] == "Normal") {
                $results["stats"] = self::getNormal($item);
                $results["stats"] = $results["stats"][0];
                
                return $results;
            }
            
            // Magic Item
            if ($shared[0]["rarity"] != "Normal") {
                $results["stats"] = self::getUnique($item);
                $results["stats"] = $results["stats"][0];
                
                $results["props"] = self::getProps($item);
                $results["props"] = $results["props"][0];
                
                return $results;
            }
        }
	}
	
	// Collects some shared item info
    private function getShared($item) {
        $query = "
            (SELECT name, type as basictype, levelreq, rarity, level, xpac
                FROM loot_normal
                WHERE `tersename` = '$item')
            UNION
            (SELECT name, basic as basictype, levelreq, rarity, level, xpac
                FROM loot_unique
                WHERE `tersename` = '$item')
            ORDER BY
                rarity DESC,
                level DESC
        ";
        F3::sql($query);
		return F3::get('DB.result');
    }
    
    private function getNormal($item) {
        $query = "
            SELECT *
            FROM loot_normal
            WHERE `tersename` = '$item'
        ";
        F3::sql($query);
        return F3::get('DB.result');
    }

    private function getUnique($item) {
        $query = "
            SELECT *
            FROM loot_normal
            JOIN loot_unique
            ON loot_normal.name = loot_unique.basic
            WHERE loot_unique.tersename = '$item'
        ";
        F3::sql($query);
        return F3::get('DB.result');
    }

    private function getProps($item) {
        $query = "
            SELECT property, param, min, max
            FROM loot_unique_properties
            WHERE name = '$item'
        ";
        F3::sql($query);
        return F3::get('DB.result');
    }
    
    private function propTranslate($prop, $param, $min, $max) {
        echo "on the todo list";
    }
}