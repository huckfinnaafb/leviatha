<?php
/**
 * Development scripts
 *
 * @author Sam
 */
class basecontroller {

    public static function show($file, $meta = null) {
        include (F3::get('GUI') . "leviathan.php");
    }
}