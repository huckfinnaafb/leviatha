<?php
class search extends basecontroller {

    public static function main() {
        // Query is entered
        $meta['title'] = $_GET['q'];
        parent::show(F3::get('GUI') . 'search.php', $meta);
    }

    public static function strprep($string) {
        $string = htmlspecialchars($string);
        $string = mysql_escape_string($string);
        $string = str_replace(' ', '-', $string);
        $string = str_replace("'", '', $string);
        return $string;
    }
    
    public static function searchLoot($term = null) {
        
        if ($term == null) { return 0; }
        
        $term = self::strprep($term);
        $query = "
            (SELECT name, tersename, class, type as sharedtype, levelreq, rarity, level, xpac
                FROM loot_normal
                WHERE UPPER(`tersename`)
                LIKE UPPER('%$term%'))
            UNION
            (SELECT name, tersename, class, basic as sharedtype, levelreq, rarity, level, xpac
                FROM loot_unique
                WHERE UPPER(`tersename`)
                LIKE UPPER('%$term%'))
            ORDER BY 
                rarity DESC,
                level DESC
            LIMIT 40
        ";
        F3::sql($query);
        return F3::get('DB.result');
    }
}