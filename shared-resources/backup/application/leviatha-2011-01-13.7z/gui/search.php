<?php
if (isset($_GET['q'])) {

    // Nab results
    $results = search::searchLoot($_GET['q']);
    
    // Set meta info
    $meta['title'] = $_GET['q'];
    
    // Conditional behavior
    if ($_GET['q'] = '') {
        echo "Nothing entered idiot";
    }
    else if (!count($results)) {
        echo "nothing found lol";
    }
}
else F3::reroute("/");
?>
<div class="module mod-tip">
    <p>Look for more items using the <a href="/loot" class="link">Master Loot Directory</a>.</p>
</div>
<div class="module mod-search">
    <table class="table table-search">
        <thead class="thead thead-search">
            <tr>
                <th class="theading theading-search">Name</th>
                <th class="theading theading-search">Class</th>
                <th class="theading theading-search">Type</th>
                <th class="theading theading-search">Level Req.</th>
                <th class="theading theading-search">Item Level</th>
            </tr>
        </thead>
        <tbody class="tbody tbody-search"><?php
            foreach ($results as $row) {
                echo ("
                <tr class='trow trow-" . strtolower($row['rarity']) . "'>
                    <td class=\"tdata\"><a class='link link-item' href='loot?item={$row['tersename']}'>{$row['name']}</a></td>
                    <td class=\"tdata\">{$row['class']}</td>
                    <td class=\"tdata\">{$row['sharedtype']}</td>
                    <td class=\"tdata\">{$row['levelreq']}</td>
                    <td class=\"tdata\">{$row['level']}</td>
                </tr>");
            }
            ?>

        </tbody>
    </table>
</div>