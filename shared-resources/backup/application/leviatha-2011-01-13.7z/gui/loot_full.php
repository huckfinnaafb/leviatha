<?php $row = loot::getItem(); ?>
<div class="module">
	<div class="node">
		<img src="/img/stormshield.png" class="img img-float">
		<h1 class="heading h-page"><?php echo $row["stats"]["name"] ?></h1>
		<p><?php echo "Level {$row["stats"]['level']} {$row["stats"]['class']} {$row["stats"]['type']}" ?></p>
		<p><?php echo "Level Required: {$row["stats"]['levelreq']}" ?></p>
	</div>
    <table class="table table-loot">
        <?php if ($row["stats"]['minac']) { ?><tr class="trow"><th class="theading">Defense:</th><td><?php echo "(" . $row["stats"]['minac'] . " - " . $row["stats"]['maxac'] . ")" ?></td></tr><?php } ?>
        
        <?php
			// Kick Damage
            if ($row["stats"]['type'] == "Boots") { ?>
                <tr class="trow"><th class="theading">Kick Damage:</th><td><?php echo "(" . $row["stats"]['mindam'] . " - " . $row["stats"]['maxdam'] . ")"; ?></td></tr><?php } ?>
        <?php
			// Smite Damage
            if ($row["stats"]['type'] == "Shield" || $row["stats"]['type'] == "Paladin Shield") { ?>
                <tr class="trow"><th class="theading">Smite Damage:</th><td><?php echo "(" . $row["stats"]['mindam'] . " - " . $row["stats"]['maxdam'] . ")"; ?></td></tr><?php } ?>
        <?php 
			// Weapon Damage
            if ($row["stats"]['type'] != "Necromancer Head" && $row["stats"]['type'] != "Shield" && $row["stats"]['type'] != "Paladin Shield" && $row["stats"]['type'] != "Boots") { ?>
                <?php if ($row["stats"]['mindam']) { ?><tr class="trow"><th class="theading">One Hand Damage:</th><td><?php echo "(" . $row["stats"]['mindam'] . " - " . $row["stats"]['maxdam'] . ")"; ?></td></tr><?php } ?>
            <?php } ?>
        
		<?php if ($row["stats"]['2handedmindam'] != NULL) { ?><tr class="trow"><th class="theading">Two Hand Damage   :</th><td><?php echo "(" . $row["stats"]['2handedmindam'] . " - " . $row["stats"]['2handedmaxdam'] . ")" ?></td></tr><?php } ?>
		<?php if ($row["stats"]['missilemindam'] != NULL) { ?><tr class="trow"><th class="theading">Thrown Damage     :</th><td><?php echo "(" . $row["stats"]['missilemindam'] . " - " . $row["stats"]['missilemaxdam'] . ")" ?></td></tr><?php } ?>
		<?php if ($row["stats"]['reqstr'] != NULL) { ?>       <tr class="trow"><th class="theading">Required Strength :</th><td><?php echo $row["stats"]['reqstr'] ?></td></tr><?php } ?>
		<?php if ($row["stats"]['reqdex'] != NULL) { ?>       <tr class="trow"><th class="theading">Required Dexterity:</th><td><?php echo $row["stats"]['reqdex'] ?></td></tr><?php } ?>
		<?php if ($row["stats"]['strbonus'] != NULL) { ?>     <tr class="trow"><th class="theading">Strength Bonus    :</th><td><?php echo $row["stats"]['strbonus'] ?></td></tr><?php } ?>
		<?php if ($row["stats"]['dexbonus'] != NULL) { ?>     <tr class="trow"><th class="theading">Dexterity Bonus   :</th><td><?php echo $row["stats"]['dexbonus'] ?></td></tr><?php } ?>
		<?php if ($row["stats"]['gemsockets'] != NULL) { ?>   <tr class="trow"><th class="theading">Max Sockets           :</th><td><?php echo $row["stats"]['gemsockets'] ?></td></tr><?php } ?>
		<?php if ($row["stats"]['range'] != NULL) { ?>        <tr class="trow"><th class="theading">Range             :</th><td><?php echo $row["stats"]['range'] ?></td></tr><?php } ?>
		<?php if ($row["stats"]['weaponspeed'] != NULL) { ?>  <tr class="trow"><th class="theading">Weapon Speed      :</th><td><?php echo $row["stats"]['weaponspeed'] ?></td></tr><?php } ?>
		<?php if ($row["stats"]['durability'] != NULL) { ?>   <tr class="trow"><th class="theading">Durability        :</th><td><?php echo $row["stats"]['durability'] ?></td></tr><?php } ?>
		<?php if ($row["stats"]['maxstack'] != NULL) { ?>     <tr class="trow"><th class="theading">Max Quantity      :</th><td><?php echo $row["stats"]['maxstack'] ?></td></tr><?php } ?>
		<?php if ($row["stats"]['absorbs'] != NULL) { ?>      <tr class="trow"><th class="theading">Absorbtion        :</th><td><?php echo $row["stats"]['absorbs'] ?></td></tr><?php } ?>
		<?php if ($row["stats"]['armorspeed'] != NULL) { ?>   <tr class="trow"><th class="theading">Speed Penalty     :</th><td><?php echo $row["stats"]['armorspeed'] ?></td></tr><?php } ?>
    </table>
</div>