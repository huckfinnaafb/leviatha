<?php
define ('__SITE_PATH', realpath(dirname(__DIR__)));

// PHP Fat Free Framework (http://fatfree.sourceforge.net/)
require_once (__SITE_PATH . "/library/F3/F3/F3.php");

// Framework settings and configurations
F3::set('RELEASE',FALSE);
F3::set('GUI', __SITE_PATH . '/gui/');
F3::set('DB',
    array(
        'dsn'=>'mysql:host=127.0.0.1;port=3306;dbname=leviathan',
        'user'=>'leviathan',
        'password'=>'B9RXS6cGUhQzNXJw'
    )
);
F3::set('AUTOLOAD',
    __SITE_PATH . "/application/|" .
    __SITE_PATH . "/library/F3/autoload/");
F3::set('GET',F3::scrub($_GET));

// Routers
F3::route('GET /',
    function () {
        include (F3::get('GUI') . "default.html");
    }
);
F3::route('GET /search', "search::main");
F3::route('GET /loot',
    function () {
        // /loot?item=item-name
        if (isset($_GET["item"])) {
        
            // /loot=?item=
            if ($_GET["item"] == '') {
                F3::reroute("/loot"); 
            }
            else {
                $meta['title'] = $_GET['item'];
                basecontroller::show(F3::get('GUI') . 'loot.php', $meta);
            }
        }
        // /loot
        else {
            $meta['title'] = "Loot Directory";
            basecontroller::show(F3::get('GUI') . 'lootdirectory.html', $meta);
        }
    }
);
F3::route('GET /sitemap',
	function() {
		F3::sitemap();
	}
);

F3::run();